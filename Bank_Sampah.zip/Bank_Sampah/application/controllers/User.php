<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('is_logged_in')) {
            $this->session->set_flashdata('error', 'Anda harus login terlebih dahulu!');
            redirect('auth/login');
        }

        $this->load->model('Setoran_model');
        $this->load->model('Saldo_model');
    }

    public function dashboard()
    {
        $user_id = $this->session->userdata('user_id');

        $data['total_berat'] = $this->Setoran_model->get_total_berat_by_user($user_id);
        $saldo = $this->Saldo_model->getSaldoByUserId($user_id);
        $data['poin'] = $saldo ? $saldo->poin : 0;

        $this->load->view('users/template/header');
        $this->load->view('users/dashboard', $data);
        $this->load->view('users/template/footer');
    }

    public function setor()
    {
        // Tambahkan data jika diperlukan
        $this->load->view('users/template/header');
        $this->load->view('users/setor');
        $this->load->view('users/template/footer');
    }

    public function riwayat()
    {
        $user_id = $this->session->userdata('user_id');
        $data['setoran'] = $this->Setoran_model->get_by_user($user_id);
        $data['total_berat'] = $this->Setoran_model->get_total_berat_by_user($user_id);

        $this->load->view('users/template/header');
        $this->load->view('users/riwayat_setor', $data);
        $this->load->view('users/template/footer');
    }


    public function saldo()
    {
        $this->load->model('Saldo_model');
        $user_id = $this->session->userdata('user_id');
        $data['saldo'] = $this->Saldo_model->getSaldoByUserId($user_id);

        $this->load->view('users/template/header');
        $this->load->view('users/saldo', $data);
        $this->load->view('users/template/footer');
    }

    public function withdraw()
    {
        $this->load->model('Withdraw_model');
        $this->load->model('Saldo_model');

        $user_id = $this->session->userdata('user_id');
        $saldo = $this->Saldo_model->getSaldoByUserId($user_id);

        if ($this->input->method() == 'post') {
            $poin = (int)$this->input->post('poin');
            $rupiah = $poin * 100;

            $bank = $this->input->post('bank');
            $no_rekening = $this->input->post('no_rekening');
            $nama_rekening = $this->input->post('nama_rekening');

            if ($poin < 300) {
                $this->session->set_flashdata('error', 'Minimal penukaran 300 poin.');
            } elseif (!$saldo || $saldo->poin < $poin) {
                $this->session->set_flashdata('error', 'Poin tidak mencukupi.');
            } elseif (empty($bank) || empty($no_rekening) || empty($nama_rekening)) {
                $this->session->set_flashdata('error', 'Semua data rekening harus diisi.');
            } else {
                // Kurangi poin user
                $this->Saldo_model->kurangiPoin($user_id, $poin);

                // Simpan data withdraw
                $data = [
                    'user_id' => $user_id,
                    'poin' => $poin,
                    'rupiah' => $rupiah,
                    'bank' => $bank,
                    'no_rekening' => $no_rekening,
                    'nama_rekening' => $nama_rekening,
                    'status' => 'pending',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->Withdraw_model->insert_withdraw($data);

                $this->session->set_flashdata('success', "Withdraw berhasil diajukan sebesar Rp " . number_format($rupiah, 0, ',', '.'));
            }

            redirect('user/riwayat_withdraw');
        }

        $data['saldo'] = $saldo;
        $data['riwayat'] = $this->Withdraw_model->get_by_user($user_id);

        $this->load->view('users/template/header');
        $this->load->view('users/withdraw', $data);
        $this->load->view('users/template/footer');
    }

    public function riwayat_withdraw()
    {
        // Pastikan user sudah login
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login'); // atau sesuai dengan sistem login kamu
        }

        $user_id = $this->session->userdata('user_id');

        // Load model
        $this->load->model('Withdraw_model');

        // Ambil data dari model
        $data['riwayat'] = $this->Withdraw_model->get_by_user($user_id);

        // Tampilkan view
        $this->load->view('users/template/header');
        $this->load->view('users/riwayat_withdraw', $data);
        $this->load->view('users/template/footer');
    }


    public function profile()
    {
        // Pastikan user sudah login
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $this->load->model('User_model');
        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));

        $this->load->view('users/template/header');
        $this->load->view('users/profile', $data);
        $this->load->view('users/template/footer');
    }

    public function edit_profile()
    {
        $user_id = $this->session->userdata('user_id');
        $this->load->model('User_model');
        $data['user'] = $this->User_model->get_by_id($user_id);

        if ($this->input->method() == 'post') {
            $post = $this->input->post();

            $update_data = [
                'username'      => $post['username'],
                'nama_lengkap'  => $post['nama_lengkap'],
                'email'         => $post['email'],
                'no_hp'         => $post['no_hp'],
                'alamat'        => $post['alamat']
            ];

            // Upload foto profil jika ada
            if (!empty($_FILES['foto']['name'])) {
                $config['upload_path']   = './asset/uploads/foto_profile/';
                $config['allowed_types'] = 'jpg|jpeg|png';
                $config['max_size']      = 2048;
                $config['file_name']     = 'profile_' . $user_id;
                $config['overwrite']     = true;

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('foto')) {
                    $upload_data = $this->upload->data();
                    $update_data['foto'] = $upload_data['file_name'];
                } else {
                    $this->session->set_flashdata('error', $this->upload->display_errors());
                    redirect('user/edit_profile');
                    return;
                }
            }

            if (!empty($post['password'])) {
                if ($post['password'] === $post['confirm_password']) {
                    $update_data['password'] = password_hash($post['password'], PASSWORD_DEFAULT);
                } else {
                    $this->session->set_flashdata('error', 'Konfirmasi password tidak sesuai.');
                    redirect('user/edit_profile');
                    return;
                }
            }

            if ($this->User_model->update($user_id, $update_data)) {
                $this->session->set_flashdata('success', 'Profil berhasil diperbarui.');
            } else {
                $this->session->set_flashdata('error', 'Terjadi kesalahan saat memperbarui profil.');
            }

            redirect('user/profile');
        }

        $this->load->view('users/template/header');
        $this->load->view('users/edit_profile', $data);
        $this->load->view('users/template/footer');
    }
}
