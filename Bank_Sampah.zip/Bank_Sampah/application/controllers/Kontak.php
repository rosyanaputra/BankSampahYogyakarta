<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kontak extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Kontak_model');
    }

    public function index()
    {
        $this->load->view('template/header');
        $this->load->view('kontak');
        $this->load->view('template/footer'); // Load the contact view
    }

    public function send_message()
    {
        $this->form_validation->set_rules('name', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('phone', 'Nomor Telepon', 'required');
        $this->form_validation->set_rules('message', 'Pesan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->index(); // Reload the form with validation errors
        } else {
            $data = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'phone' => $this->input->post('phone'),
                'message' => $this->input->post('message'),
                'created_at' => date('Y-m-d H:i:s')
            );

            if ($this->Kontak_model->insert_message($data)) {
                $this->session->set_flashdata('success', 'Pesan Anda telah dikirim!');
                redirect('kontak'); // Redirect to the contact page
            } else {
                $this->session->set_flashdata('error', 'Gagal mengirim pesan. Silakan coba lagi.');
                redirect('kontak'); // Redirect to the contact page
            }
        }
    }
}
