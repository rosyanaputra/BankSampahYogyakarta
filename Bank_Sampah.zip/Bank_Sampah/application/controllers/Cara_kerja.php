<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cara_kerja extends CI_Controller
{

    public function index()
    {
        $this->load->view('template/header');
        $this->load->view('cara_kerja');
        $this->load->view('template/footer');
    }
}
