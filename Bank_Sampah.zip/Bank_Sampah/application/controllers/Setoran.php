<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Setoran extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Setoran_model');
        $this->load->model('Saldo_model');
    }

    public function index()
    {
        $this->load->view('form_setoran');
    }

    public function simpan()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('jenisSampah', 'Jenis Sampah', 'required');
        $this->form_validation->set_rules('berat', 'Berat', 'required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('latitude', 'Latitude', 'required|numeric');
        $this->form_validation->set_rules('longitude', 'Longitude', 'required|numeric');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form_setoran');
        } else {
            $jenis = $this->input->post('jenisSampah');
            $berat = (float)$this->input->post('berat');

            $poinPerKg = [
                'organik' => 2,
                'anorganik'  => 6,
                'B3' => 10,
            ];

            $poin = isset($poinPerKg[$jenis]) ? floor($poinPerKg[$jenis] * $berat) : 0;

            $data = [
                'user_id'      => $this->session->userdata('user_id'),
                'jenis_sampah' => $jenis,
                'berat'        => $berat,
                'catatan'      => $this->input->post('catatan'),
                'alamat'       => $this->input->post('alamat'),
                'latitude'     => $this->input->post('latitude'),
                'longitude'    => $this->input->post('longitude'),
                'poin'         => $poin
            ];

            if ($this->Setoran_model->simpan($data)) {
                $user_id = $this->session->userdata('user_id');
                $this->Saldo_model->tambahPoin($user_id, $poin);

                $this->session->set_flashdata('success', 'Setoran berhasil, poin berhasil ditambahkan.');
                redirect('user/riwayat');
            } else {
                $this->session->set_flashdata('error', 'Gagal menyimpan data.');
                $this->load->view('user/setor');
            }
        }
    }
}
