<?php
// File: application/controllers/Auth.php

defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        redirect('auth/login');
    }

    public function register()
    {
        // Jika POST, proses data
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Set pesan error dalam bahasa Indonesia
            $this->form_validation->set_message([
                'required'      => '{field} wajib diisi.',
                'is_unique'     => '{field} sudah digunakan.',
                'valid_email'   => 'Format {field} tidak valid.',
                'min_length'    => '{field} minimal {param} karakter.',
                'matches'       => '{field} tidak cocok dengan Password.'
            ]);

            // Set aturan validasi
            $this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.username]');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
            $this->form_validation->set_rules('konfirmasi_password', 'Konfirmasi Password', 'required|matches[password]');

            // Cek validasi
            if ($this->form_validation->run() == FALSE) {
                $this->load->view('auth/register');
            } else {
                $data = [
                    'username'    => htmlspecialchars($this->input->post('username', true)),
                    'email'       => htmlspecialchars($this->input->post('email', true)),
                    'password'    => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                    'foto'        => 'default.jpeg',
                    'role' => 'user', // <--- default
                    'created_at'  => date('Y-m-d H:i:s')
                ];

                $this->User_model->insert_user($data);
                $this->session->set_flashdata('success', 'Registrasi berhasil! Silakan login.');
                redirect('auth/login');
            }
        } else {
            // Jika GET, tampilkan halaman
            $this->load->view('auth/register');
        }
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $user = $this->User_model->get_user_by_email($email);

            if ($user) {
                if (password_verify($password, $user['password'])) {
                    $this->session->set_userdata([
                        'user_id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email'],
                        'foto' => $user['foto'],
                        'role' => $user['role'],
                        'is_logged_in' => true
                    ]);

                    // Redirect sesuai role
                    if ($user['role'] === 'admin') {
                        redirect('admin/dashboard');
                    } else {
                        redirect('user/dashboard');
                    }
                } else {
                    $this->session->set_flashdata('error', 'Password salah. Silakan coba lagi.');
                    redirect('auth/login');
                }
            } else {
                $this->session->set_flashdata('error', 'Akun tidak ditemukan. Silakan daftar terlebih dahulu.');
                redirect('auth/register');
            }
        } else {
            $this->load->view('auth/login');
        }
    }

    public function logout()
    {
        // Hapus semua data session
        $this->session->sess_destroy();

        // Redirect ke halaman login
        redirect('auth/login');
    }
}
