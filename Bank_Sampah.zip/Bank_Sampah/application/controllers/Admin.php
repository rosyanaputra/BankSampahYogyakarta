<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // Cek session apakah sudah login sebagai admin
        if ($this->session->userdata('role') !== 'admin') {
            redirect('auth/login'); // atau redirect ke halaman user biasa
        }
    }

    public function dashboard()
    {
        // Data tambahan bisa kamu isi di sini
        $data['title'] = 'Dashboard Admin';

        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/dashboard', $data);
        $this->load->view('admin/template/footer');
    }

    public function profile()
    {
        // Pastikan user sudah login
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $this->load->model('Admin_model');
        $data['user'] = $this->Admin_model->get_by_id($this->session->userdata('user_id'));

        $this->load->view('admin/template/header');
        $this->load->view('admin/profile', $data);
        $this->load->view('admin/template/footer');
    }

    public function edit_profile()
    {
        $user_id = $this->session->userdata('user_id');
        $this->load->model('Admin_model');
        $data['user'] = $this->Admin_model->get_by_id($user_id);

        if ($this->input->method() == 'post') {
            $post = $this->input->post();

            $update_data = [
                'username'      => $post['username'],
                'nama_lengkap'  => $post['nama_lengkap'],
                'email'         => $post['email'],
                'no_hp'         => $post['no_hp'],
                'alamat'        => $post['alamat']
            ];

            // Upload foto profil jika ada
            if (!empty($_FILES['foto']['name'])) {
                $config['upload_path']   = './asset/uploads/foto_profile/';
                $config['allowed_types'] = 'jpg|jpeg|png';
                $config['max_size']      = 2048;
                $config['file_name']     = 'profile_' . $user_id;
                $config['overwrite']     = true;

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('foto')) {
                    $upload_data = $this->upload->data();
                    $update_data['foto'] = $upload_data['file_name'];
                } else {
                    $this->session->set_flashdata('error', $this->upload->display_errors());
                    redirect('admin/edit_profile');
                    return;
                }
            }

            if (!empty($post['password'])) {
                if ($post['password'] === $post['confirm_password']) {
                    $update_data['password'] = password_hash($post['password'], PASSWORD_DEFAULT);
                } else {
                    $this->session->set_flashdata('error', 'Konfirmasi password tidak sesuai.');
                    redirect('admin/edit_profile');
                    return;
                }
            }

            if ($this->Admin_model->update($user_id, $update_data)) {
                $this->session->set_flashdata('success', 'Profil berhasil diperbarui.');
            } else {
                $this->session->set_flashdata('error', 'Terjadi kesalahan saat memperbarui profil.');
            }

            redirect('admin/profile');
        }

        $this->load->view('admin/template/header');
        $this->load->view('admin/edit_profile', $data);
        $this->load->view('admin/template/footer');
    }

    public function manajemen_pengguna()
    {
        $this->load->model('Admin_model');

        $data['users'] = $this->Admin_model->get_all_users();

        $this->load->view('admin/template/header');
        $this->load->view('admin/manajemen_pengguna', $data);
        $this->load->view('admin/template/footer');
    }

    public function hapus_pengguna($id)
    {
        $this->load->model('Admin_model');

        if ($this->Admin_model->delete_user($id)) {
            $this->session->set_flashdata('success', 'Pengguna berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus pengguna.');
        }

        redirect('admin/manajemen_pengguna');
    }

    public function data_setor()
    {
        $this->load->model('Setoran_model');
        $data['setoran'] = $this->Setoran_model->get_all();
        $this->load->view('admin/template/header');
        $this->load->view('admin/data_setor', $data);
        $this->load->view('admin/template/footer');
    }

    public function update_status_setoran()
    {
        $id = $this->input->post('id');
        $status = $this->input->post('status');

        if ($id && in_array($status, ['menunggu', 'sedang diproses', 'selesai'])) {
            $this->load->model('Setoran_model');
            $this->Setoran_model->update_status($id, $status);
            echo "OK";
        } else {
            http_response_code(400);
            echo "Invalid";
        }
    }

    public function withdraw()
    {
        $this->load->model('Withdraw_model');
        $this->db->select('withdraw.*, users.username');
        $this->db->from('withdraw');
        $this->db->join('users', 'users.id = withdraw.user_id');
        $this->db->order_by('created_at', 'DESC');
        $data['withdraws'] = $this->db->get()->result();

        $this->load->view('admin/template/header');
        $this->load->view('admin/withdraw', $data);
        $this->load->view('admin/template/footer');
    }

    public function konfirmasi_withdraw($id)
    {
        $this->load->model('Withdraw_model');

        if ($this->Withdraw_model->update($id, ['status' => 'success'])) {
            $this->session->set_flashdata('success', 'Withdraw berhasil dikonfirmasi.');
        } else {
            $this->session->set_flashdata('error', 'Gagal mengonfirmasi withdraw.');
        }

        redirect('admin/withdraw');
    }

    public function saldo_pengguna()
    {
        $this->load->model('Saldo_model');
        $data['saldo_pengguna'] = $this->Saldo_model->get_all_saldo_with_user();
        $this->load->view('admin/template/header');
        $this->load->view('admin/saldo_pengguna', $data);
        $this->load->view('admin/template/footer');
    }

    public function detail_saldo($user_id)
    {
        $this->load->model('Saldo_model');
        $this->load->model('Admin_model');
        $this->load->model('Setoran_model');
        $this->load->model('Withdraw_model');

        // Ambil data user
        $data['user'] = $this->Admin_model->get_by_id($user_id);
        // Ambil data saldo user
        $data['saldo'] = $this->Saldo_model->getSaldoByUserId($user_id);
        // Ambil riwayat setoran
        $data['riwayat_setor'] = $this->Setoran_model->get_by_user($user_id);
        // Ambil riwayat withdraw
        $data['riwayat_withdraw'] = $this->Withdraw_model->get_by_user($user_id);

        // Tampilkan halaman
        $this->load->view('admin/template/header');
        $this->load->view('admin/detail_saldo_pengguna', $data);
        $this->load->view('admin/template/footer');
    }
}
