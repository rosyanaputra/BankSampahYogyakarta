<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Artikel extends CI_Controller
{
    public function index()
    {
        $apiKey = 'd99b2d5a788441f2ab4e45e19b840cb7'; // Ganti dengan API Key kamu
        $keyword = urlencode('"edukasi sampah" OR "pengelolaan sampah" OR "daur ulang" OR "sampah organik" OR "sampah anorganik"');
        $fromDate = date('Y-m-d', strtotime('-30 days')); // Maksimal 30 hari ke belakang
        $toDate = date('Y-m-d'); // Hari ini

        $endpoint = "https://newsapi.org/v2/everything?q={$keyword}&from={$fromDate}&to={$toDate}&language=id&sortBy=publishedAt&pageSize=100&apiKey={$apiKey}";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'User-Agent: BankSampahApp/1.0 (https://banksampah-digital.com)'
        ]);
        $response = curl_exec($ch);
        curl_close($ch);


        $articles = [];

        if ($response !== false) {
            $data = json_decode($response, true);

            if (isset($data['articles'])) {
                $articles = $data['articles'];
            }
        }

        $data['articles'] = $articles;

        $this->load->view('template/header');
        $this->load->view('artikel', $data);
        $this->load->view('template/footer');
    }
}
