<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function insert_admin($data)
    {
        return $this->db->insert('users', $data);
    }

    public function get_user_by_email($email)
    {
        return $this->db->get_where('users', ['email' => $email])->row_array();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where('users', ['id' => $id])->row();
    }

    public function update($id, $data)
    {
        return $this->db->update('users', $data, ['id' => $id]);
    }

    public function get_all_users()
    {
        $this->db->where('role', 'user'); // jika ada kolom role
        return $this->db->get('users')->result();
    }

    public function delete_user($id)
    {
        return $this->db->delete('users', ['id' => $id]);
    }
}
