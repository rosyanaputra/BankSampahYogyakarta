<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Saldo_model extends CI_Model
{
    public function getSaldoByUserId($user_id)
    {
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('saldo');
        return $query->row();
    }

    public function tambahPoin($user_id, $poin)
    {
        $this->db->set('poin', 'poin + ' . (int)$poin, false);
        $this->db->where('user_id', $user_id);
        $updated = $this->db->update('saldo');

        // Jika update gagal (karena tidak ada record), insert
        if ($this->db->affected_rows() == 0) {
            $this->db->insert('saldo', ['user_id' => $user_id, 'poin' => $poin]);
        }
    }

    public function kurangiPoin($user_id, $poin)
    {
        $saldo = $this->getSaldoByUserId($user_id);
        if ($saldo && $saldo->poin >= $poin) {
            $this->db->where('user_id', $user_id);
            $this->db->update('saldo', ['poin' => $saldo->poin - $poin]);
            return true;
        }
        return false;
    }

    // ✅ Fungsi untuk admin - ambil semua saldo + user
    public function get_all_saldo_with_user()
    {
        $this->db->select('users.id as user_id, users.username, users.nama_lengkap, saldo.poin');
        $this->db->from('saldo');
        $this->db->join('users', 'users.id = saldo.user_id');
        $this->db->order_by('users.nama_lengkap', 'ASC');
        return $this->db->get()->result();
    }
}
