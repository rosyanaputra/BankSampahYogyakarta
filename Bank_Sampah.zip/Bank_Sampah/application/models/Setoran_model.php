<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Setoran_model extends CI_Model
{
    // Menyimpan data setoran baru
    public function simpan($data)
    {
        return $this->db->insert('setoran_sampah', $data);
    }

    // Mendapatkan semua data setoran untuk admin (join dengan tabel user)
    public function get_all()
    {
        $this->db->select('setoran_sampah.*, users.username');
        $this->db->from('setoran_sampah');
        $this->db->join('users', 'setoran_sampah.user_id = users.id');
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get()->result();
    }

    // Mendapatkan semua setoran oleh user tertentu
    public function get_by_user($user_id)
    {
        return $this->db->get_where('setoran_sampah', ['user_id' => $user_id])->result();
    }

    // Mendapatkan total berat yang pernah disetor oleh user tertentu
    public function get_total_berat_by_user($user_id)
    {
        $this->db->select_sum('berat');
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('setoran_sampah');
        return $query->row()->berat;
    }

    // Mengupdate status setoran berdasarkan ID
    public function update_status($id, $status)
    {
        return $this->db->update('setoran_sampah', ['status' => $status], ['id' => $id]);
    }
}
