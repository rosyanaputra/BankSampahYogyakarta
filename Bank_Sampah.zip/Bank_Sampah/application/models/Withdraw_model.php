<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Withdraw_model extends CI_Model
{
    public function insert_withdraw($data)
    {
        return $this->db->insert('withdraw', $data);
    }

    public function get_by_user($user_id)
    {
        $this->db->where('user_id', $user_id);
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get('withdraw')->result();
    }

    public function update($id, $data)
    {
        return $this->db->update('withdraw', $data, ['id' => $id]);
    }
}
