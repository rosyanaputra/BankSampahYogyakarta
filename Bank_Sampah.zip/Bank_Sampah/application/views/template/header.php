<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Sampah Digital - Yogyakarta</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #2e7d32;
            --secondary-color: #7cb342;
            --accent-color: #c8e6c9;
            --dark-color: #1b5e20;
            --light-color: #f1f8e9;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: #333;
            overflow-x: hidden;
        }

        .navbar-brand img {
            height: 40px;
        }

        .hero-section {
            background: linear-gradient(rgba(46, 125, 50, 0.8), rgba(46, 125, 50, 0.8)),
                url('<?php echo base_url('asset/img/gambar_1.jpeg'); ?>') no-repeat center center;
            background-size: cover;
            color: white;
            padding: 120px 0 80px;
            position: relative;
        }

        .hero-section h1 {
            font-weight: 700;
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .hero-section p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
        }

        .btn-primary-custom {
            background-color: var(--light-color);
            color: var(--dark-color);
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 10px;
            transition: all 0.3s;
        }

        .btn-primary-custom:hover {
            background-color: var(--accent-color);
            transform: translateY(-3px);
        }

        .feature-box {
            padding: 30px;
            border-radius: 15px;
            background-color: white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
            height: 100%;
            border-top: 5px solid var(--secondary-color);
        }

        .feature-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }

        .feature-icon {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        .how-it-works-section {
            background-color: var(--light-color);
            padding: 80px 0;
        }

        .step-card img {
            height: 180px;
            /* Atur tinggi sesuai kebutuhan */
            width: 100%;
            object-fit: cover;
            object-position: center;
        }

        .step-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            text-align: center;
            position: relative;
            margin-bottom: 30px;
            transition: all 0.3s;
        }

        .step-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .step-number {
            width: 50px;
            height: 50px;
            background-color: var(--secondary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
        }

        .testimonial-section {
            padding: 80px 0;
        }

        .testimonial-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin: 15px;
        }

        .testimonial-img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
        }

        .footer {
            background-color: var(--dark-color);
            color: white;
            padding: 60px 0 20px;
        }

        .footer a {
            color: var(--accent-color);
            text-decoration: none;
        }

        .footer a:hover {
            color: white;
        }

        .social-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            transition: all 0.3s;
        }

        .social-icon:hover {
            background-color: var(--secondary-color);
            transform: translateY(-3px);
        }

        .cta-section {
            background-color: var(--secondary-color);
            color: white;
            padding: 60px 0;
        }

        .cta-section h2 {
            font-weight: 700;
        }

        .map-container {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2.2rem;
            }

            .hero-section p {
                font-size: 1rem;
            }
        }

        .step-card {
            background-color: #ffffff;
            border-radius: 16px;
            padding: 20px;
            height: 100%;
            /* Penting: agar flex-grow bekerja */
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            text-align: center;
        }

        .step-number {
            font-size: 24px;
            font-weight: bold;
            color: white;
            background-color: #28a745;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
        }

        .row.equal-height {
            display: flex;
            flex-wrap: wrap;
        }

        .row.equal-height>[class*="col-"] {
            display: flex;
            flex-direction: column;
        }
    </style>
</head>

<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background-color: var(--primary-color);">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="<?php echo base_url('asset/img/logo_bg_white.png'); ?>" alt="Bank Sampah Digital Logo" class="me-2 rounded">
                <span>
                    <H6>ECOJOGJA</H6>
                </span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo site_url('landing_page'); ?>">BERANDA</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo site_url('tentang_kami'); ?>">TENTANG KAMI</a>
                    </li>
                    <li class=" nav-item">
                        <a class="nav-link active" href="<?php echo site_url('layanan'); ?>">LAYANAN</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo site_url('cara_kerja'); ?>">CARA KERJA</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo site_url('artikel'); ?>">ARTIKEL</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo site_url('kontak'); ?>">KONTAK</a>
                    </li>
                    <li class="nav-item ms-lg-3">
                        <div class="btn-group overflow-hidden shadow-sm" role="group">
                            <a href="<?php echo site_url('auth/login'); ?>" class="btn btn-primary-custom btn-sm fw-semibold px-2 py-2">
                                LOGIN
                            </a>
                            <a href="<?php echo site_url('auth/register'); ?>" class="btn btn-primary-custom btn-sm fw-semibold px-2 py-2">
                                DAFTAR
                            </a>
                        </div>
                    </li>

                </ul>
            </div>
        </div>
    </nav>