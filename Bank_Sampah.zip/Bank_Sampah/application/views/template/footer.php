    <!-- CTA Section -->
    <section class="cta-section text-center">
        <div class="container">
            <h2 class="mb-4">Siap Bergabung Dengan Bank Sampah Digital?</h2>
            <p class="mb-5">Mulai sekarang dan dapatkan manfaat langsung bagi keluarga dan lingkungan Anda.</p>
            <div class="d-flex justify-content-center gap-3">
                <a href="<?php echo site_url('auth/register'); ?>" class="btn btn-primary-custom" style="background-color: var(--dark-color); color: white;">
                    <i class="fas fa-user-plus me-2"></i> Daftar Sekarang
                </a>
                <a href="<?php echo site_url('layanan'); ?>" class="btn btn-primary-custom" style="background-color: white; color: var(--dark-color);">
                    <i class="fas fa-info-circle me-2"></i> Pelajari Lebih Lanjut
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="mb-4">
                        <img src="<?php echo base_url('asset/img/logo_2_bg_white.png'); ?>" alt="Bank Sampah Digital Logo" class="mb-3 rounded" height="80" width="160">
                    </div>
                    <p>Sistem Bank Sampah Digital terintegrasi pertama di Daerah Istimewa Yogyakarta yang membantu masyarakat mengelola sampah untuk lingkungan lebih bersih.</p>
                    <div class="mt-4">
                        <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4">
                    <h5 class="mb-4">Tautan Cepat</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo site_url('landing_page'); ?>">Beranda</a></li>
                        <li class="mb-2"><a href="<?php echo site_url('tentang_kami'); ?>">Tentang Kami</a></li>
                        <li class="mb-2"><a href="<?php echo site_url('layanan'); ?>">Layanan</a></li>
                        <li class="mb-2"><a href="<?php echo site_url('artikel'); ?>">Artikel</a></li>
                        <li class="mb-2"><a href="<?php echo site_url('kontak'); ?>">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-4">

                </div>
                <div class="col-lg-4 col-md-4">
                    <h5 class="mb-4">Kontak Kami</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3"><i class="fas fa-map-marker-alt me-2"></i> Jl. Kenari No. 45, Yogyakarta</li>
                        <li class="mb-3"><i class="fas fa-phone-alt me-2"></i> (0274) 555-1234</li>
                        <li class="mb-3"><i class="fas fa-envelope me-2"></i> info@banksampahjogja.id</li>
                        <li><i class="fas fa-clock me-2"></i> Senin-Sabtu, 08:00-16:00</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-5 mb-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="text-center">
                <p class="mb-0">© 2025 Bank Sampah Digital Yogyakarta. Seluruh hak cipta dilindungi.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Additional JS -->
    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
            } else {
                navbar.style.boxShadow = 'none';
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Animation on scroll
        const animateOnScroll = function() {
            const elements = document.querySelectorAll('.feature-box, .step-card, .testimonial-card');
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;

                if (elementPosition < windowHeight - 100) {
                    element.classList.add('animate__animated', 'animate__fadeInUp');
                }
            });
        };

        window.addEventListener('scroll', animateOnScroll);
        animateOnScroll(); // Run once on page load
    </script>
    </body>

    </html>