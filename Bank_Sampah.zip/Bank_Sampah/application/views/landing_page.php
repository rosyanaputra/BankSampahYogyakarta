    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="animate__animated animate__fadeInDown">Kelola Sampah Jadi Berkah</h1>
            <p class="animate__animated animate__fadeInUp">Sistem Digital Bank Sampah Yogyakarta yang memudahkan Anda mengelola sampah rumah tangga dan mendapatkan manfaat ekonomi serta lingkungan.</p>
            <a href="<?php echo site_url('auth/register'); ?>" class="btn btn-primary-custom animate__animated animate__fadeInUp animate__delay-1s">Daftar Sekarang</a>
            <div class="mt-5">
                <img src="<?php echo base_url('asset/img/gambar_1.jpeg'); ?>" alt="Illustration of people sorting different types of waste into recycling bins with digital interfaces showing rewards" class="img-fluid rounded-3">
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Mengapa Memilih Kami?</h2>
                <p class="text-muted">Solusi pengelolaan sampah modern untuk masyarakat Yogyakarta</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-recycle"></i>
                        </div>
                        <h4>Pengelolaan Digital</h4>
                        <p>Pantau transaksi sampah Anda secara real-time melalui aplikasi mobile dan web kami.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-coins"></i>
                        </div>
                        <h4>Manfaat Finansial</h4>
                        <p>Tukarkan sampah Anda menjadi poin yang bisa diuangkan atau digunakan untuk belanja.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <i class="fas fa-leaf"></i>
                        </div>
                        <h4>Lingkungan Bersih</h4>
                        <p>Berkontribusi langsung terhadap kebersihan kota Yogyakarta dan kesehatan lingkungan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="how-it-works-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Bagaimana Cara Kerjanya?</h2>
                <p class="text-muted">Hanya perlu 4 langkah sederhana untuk mengelola sampah Anda</p>
            </div>
            <div class="row g-4 equal-height">
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number">1</div>
                        <div class="mt-4">
                            <img src="<?php echo base_url('asset/img/mobile.jpeg'); ?>" alt="Icon showing mobile phone sending registration SMS" class="img-fluid mb-3 rounded">
                            <h5>Daftar</h5>
                            <p>Daftarkan diri Anda melalui website kami.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number">2</div>
                        <div class="mt-4">
                            <img src="<?php echo base_url('asset/img/pilah.jpeg'); ?>" alt="Icon showing people sorting waste into different categories" class="img-fluid mb-3 rounded">
                            <h5>Pilah Sampah</h5>
                            <p>Pilah sampah rumah tangga Anda sesuai kategori yang ditentukan.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number">3</div>
                        <div class="mt-4">
                            <img src="<?php echo base_url('asset/img/pickup.jpeg'); ?>" alt="Icon showing a truck collecting sorted waste from homes" class="img-fluid mb-3 rounded">
                            <h5>Jemput</h5>
                            <p>Penjemputan sampah sesuai titik lokasi yang ditentukan.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number">4</div>
                        <div class="mt-4">
                            <img src="<?php echo base_url('asset/img/saving.jpeg'); ?>" alt="Icon showing digital wallet receiving points from waste recycling" class="img-fluid mb-3 rounded">
                            <h5>Dapatkan Manfaat</h5>
                            <p>Tukarkan poin menjadi uang tunai.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-5" style="background-color: var(--primary-color); color: white;">
        <div class="container">
            <div class="row text-center g-4">
                <div class="col-md-3">
                    <div class="display-4 fw-bold">5000+</div>
                    <p class="text-muted">Pengguna Aktif</p>
                </div>
                <div class="col-md-3">
                    <div class="display-4 fw-bold">250+</div>
                    <p class="text-muted">Titik Pengumpulan</p>
                </div>
                <div class="col-md-3">
                    <div class="display-4 fw-bold">50+</div>
                    <p class="text-muted">Ton Per Bulan</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonial Section -->
    <section class="testimonial-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Apa Kata Mereka?</h2>
                <p class="text-muted">Testimoni dari pengguna Bank Sampah Digital Yogyakarta</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="testimonial-card">
                        <div class="d-flex align-items-center mb-3">
                            <img src="https://placehold.co/70x70" alt="Portrait of Pak Mulyono, a 45-year-old hardware store owner from Sleman" class="testimonial-img">
                            <div>
                                <h5 class="mb-0">Pak Mulyono</h5>
                                <small class="text-muted">Warga Sleman</small>
                            </div>
                        </div>
                        <p>"Sejak pakai Bank Sampah Digital, sampah rumah jadi punya nilai. Bulan lalu saya bisa menukar poin dengan sembako di warung tetangga."</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="testimonial-card">
                        <div class="d-flex align-items-center mb-3">
                            <img src="https://placehold.co/70x70" alt="Portrait of Bu Tri, a 38-year-old homemaker and PKK member from Bantul" class="testimonial-img">
                            <div>
                                <h5 class="mb-0">Bu Tri</h5>
                                <small class="text-muted">PKK Bantul</small>
                            </div>
                        </div>
                        <p>"Program ini sangat membantu membersihkan lingkungan kami. Sekarang RT kami mendapatkan penghargaan lingkungan berkat sistem Bank Sampah Digital."</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="testimonial-card">
                        <div class="d-flex align-items-center mb-3">
                            <img src="https://placehold.co/70x70" alt="Portrait of Rani, a 22-year-old college student living in a boarding house in Yogyakarta" class="testimonial-img">
                            <div>
                                <h5 class="mb-0">Rani</h5>
                                <small class="text-muted">Mahasiswa</small>
                            </div>
                        </div>
                        <p>"Sebagai anak kos, aplikasi ini sangat praktis. Saya bisa jadwal penjemputan via aplikasi dan poinnya bisa untuk bayar kebutuhan kuliah."</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Map and Coverage Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-3">Jangkauan Kami di DIY</h2>
                    <p>Bank Sampah Digital Yogyakarta sudah melayani seluruh kabupaten dan kota di Daerah Istimewa Yogyakarta dengan sistem terintegrasi.</p>
                    <div class="row mt-4">
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <span>Kota Yogyakarta</span>
                            </div>
                            <div class="d-flex align-items-center mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <span>Kab. Sleman</span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <span>Kab. Bantul</span>
                            </div>
                            <div class="d-flex align-items-center mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <span>Kab. Gunung Kidul</span>
                            </div>
                        </div>
                    </div>
                    <a href="#" class="btn btn-primary-custom mt-3">Lihat Semua Titik Pengumpulan</a>
                </div>
                <div class="col-lg-6">
                    <div class="map-container">
                        <img src="<?php echo base_url('asset/img/map.png'); ?>" alt="Map of Yogyakarta showing waste bank locations marked with green pins" height="500" width="800" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>