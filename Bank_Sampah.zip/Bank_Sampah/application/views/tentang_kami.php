    <style>
        .team-card {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .team-card img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            object-position: center;
            margin: 0 auto;
            /* ini yang memusatkan gambar secara horizontal */
            display: block;
        }
    </style>

    <!-- About Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="animate__animated animate__fadeInDown">Tentang Bank Sampah Digital Yogyakarta</h1>
            <p class="animate__animated animate__fadeInUp">Mengubah cara masyarakat Yogyakarta mengelola sampah sejak 2019 dengan inovasi teknologi dan komitmen lingkungan.</p>
            <div class="mt-5">
                <img src="<?php echo base_url('asset/img/team.png'); ?>" alt="Team photo of Bank Sampah Digital Yogyakarta staff in green uniforms" class="img-fluid rounded-3">
            </div>
        </div>
    </section>

    <!-- About Content Section -->
    <section class="py-5">
        <div class="container">
            <div class="row align-items-center g-5">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-4">Visi & Misi Kami</h2>
                    <div class="mb-5">
                        <h4><i class="fas fa-bullseye me-2 text-success"></i> Visi</h4>
                        <p>Menjadikan Yogyakarta sebagai kota percontohan pengelolaan sampah berbasis digital di Indonesia tahun 2025.</p>
                    </div>
                    <div>
                        <h4><i class="fas fa-tasks me-2 text-success"></i> Misi</h4>
                        <ul class="list-unstyled">
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Mengembangkan sistem pengelolaan sampah terintegrasi berbasis teknologi</li>
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Meningkatkan kesadaran masyarakat akan pentingnya pengelolaan sampah</li>
                            <li class="mb-3"><i class="fas fa-check-circle text-success me-2"></i> Membangun ekonomi sirkular melalui nilai tambah sampah</li>
                            <li><i class="fas fa-check-circle text-success me-2"></i> Berkolaborasi dengan berbagai pemangku kepentingan di DIY</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-img rounded-3 overflow-hidden">
                        <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/aebe0bce-992e-4da5-9e7f-2e5d7bcf8a7a.png" alt="Team members discussing waste management strategy in office" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="py-5" style="background-color: var(--light-color);">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Tim Kami</h2>
                <p class="text-muted">Profesional yang berdedikasi untuk lingkungan Yogyakarta</p>
            </div>
            <div class="row g-4 align-items-stretch">
                <div class="col-md-4">
                    <div class="team-card text-center bg-white p-4 rounded-3">
                        <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/536bc333-fa38-44e5-bfa0-7f4fb87aae19.png" alt="Photo of Budi Santoso, Founder and CEO" class="img-fluid rounded-circle mb-3">
                        <h5>Budi Santoso</h5>
                        <p class="text-muted">Founder & CEO</p>
                        <p>Pakar pengelolaan sampah dengan pengalaman 15 tahun di bidang lingkungan</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="team-card text-center bg-white p-4 rounded-3">
                        <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/5e94043d-f050-435b-8872-2f423b861811.png" alt="Photo of Ani Wijayanti, Head of Operations" class="img-fluid rounded-circle mb-3">
                        <h5>Ani Wijayanti</h5>
                        <p class="text-muted">Head of Operations</p>
                        <p>Mengelola lebih dari 50 mitra bank sampah konvensional di DIY</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="team-card text-center bg-white p-4 rounded-3">
                        <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/25ebfd34-9706-4003-ae88-c8d4b34ddeff.png" alt="Photo of Rizal Firmansyah, Head of Technology" class="img-fluid rounded-circle mb-3">
                        <h5>Rizal Firmansyah</h5>
                        <p class="text-muted">Head of Technology</p>
                        <p>Pakar aplikasi mobile dan sistem digital pengelolaan sampah</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-5" style="background-color: var(--primary-color); color: white;">
        <div class="container">
            <div class="row text-center g-4">
                <div class="col-md-3">
                    <div class="display-4 fw-bold">5000+</div>
                    <p class="text-muted">Pengguna Aktif</p>
                </div>
                <div class="col-md-3">
                    <div class="display-4 fw-bold">250+</div>
                    <p class="text-muted">Titik Pengumpulan</p>
                </div>
                <div class="col-md-3">
                    <div class="display-4 fw-bold">100+</div>
                    <p class="text-muted">Mitra Pengelola</p>
                </div>
                <div class="col-md-3">
                    <div class="display-4 fw-bold">50+</div>
                    <p class="text-muted">Ton Per Bulan</p>
                </div>
            </div>
        </div>
    </section>