    <!-- Workflow Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="animate__animated animate__fadeInDown">Bagaimana Bank Sampah Digital Bekerja</h1>
            <p class="animate__animated animate__fadeInUp">Sistem sederhana namun efektif untuk mengubah sampah menjadi berkah dalam 4 langkah mudah</p>
            <div class="mt-5">
                <img src="<?php echo base_url('asset/img/cara_kerja.jpeg'); ?>" alt="Illustration of waste bank digital workflow with 4 steps" class="img-fluid rounded-3">
            </div>
        </div>
    </section>

    <!-- Workflow Section -->
    <section class="how-it-works-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Alur Pengelolaan Sampah Digital</h2>
                <p class="text-muted">Proses sederhana dengan manfaat maksimal bagi Anda dan lingkungan</p>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number mb-3">1</div>
                        <img src="<?php echo base_url('asset/img/registrasi.jpeg'); ?>" alt="Registration illustration" class="img-fluid mb-3" style="height: 100px;">
                        <h4>Registrasi</h4>
                        <p>Daftar melalui website, verifikasi data, dan anda sudah bisa melakukan transaksi.</p>
                        <div class="step-details mt-3">
                            <p><i class="fas fa-check-circle text-success me-2"></i> Gratis</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Cukup 5 menit</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Dapat ID digital</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number mb-3">2</div>
                        <img src="<?php echo base_url('asset/img/sorting.jpeg'); ?>" alt="Sorting illustration" class="img-fluid mb-3" style="height: 100px;">
                        <h4>Pemilahan</h4>
                        <p>Pilah sampah sesuai jenis : organik, anorganik, dan B3 sesuai panduan kami</p>
                        <div class="step-details mt-3">
                            <p><i class="fas fa-check-circle text-success me-2"></i> Dapat panduan</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Alat gratis</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Bantuan online</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number mb-3">3</div>
                        <img src="<?php echo base_url('asset/img/drop_off.jpeg'); ?>" alt="Drop-off illustration" class="img-fluid mb-3" style="height: 100px;">
                        <h4>Penyerahan</h4>
                        <p>Tentukan penjemputan sampah anda via website</p>
                        <div class="step-details mt-3">
                            <p><i class="fas fa-check-circle text-success me-2"></i> QR Code</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Konfirmasi real-time</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Catat berat</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card">
                        <div class="step-number mb-3">4</div>
                        <img src="<?php echo base_url('asset/img/reward.jpeg'); ?>" alt="Reward illustration" class="img-fluid mb-3" style="height: 100px;">
                        <h4>Hasil & Manfaat</h4>
                        <p>Dapatkan poin yang bisa ditukar uang.</p>
                        <div class="step-details mt-3">
                            <p><i class="fas fa-check-circle text-success me-2"></i> Transfer ke rekening</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Voucher digital</p>
                            <p><i class="fas fa-check-circle text-success me-2"></i> Laporan bulanan</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>