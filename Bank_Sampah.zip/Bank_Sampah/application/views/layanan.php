    <!-- About Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="animate__animated animate__fadeInDown">Layanan Bank Sampah Digital Yogyakarta</h1>
            <p class="animate__animated animate__fadeInUp">Kami hadir untuk menginspirasi masyarakat Yogyakarta dalam mengelola sampah secara bijak melalui teknologi dan semangat pelestarian lingkungan.</p>
            <div class="mt-5">
                <img src="<?php echo base_url('asset/img/layanan.png'); ?>" alt="Team photo of Bank Sampah Digital Yogyakarta staff in green uniforms" class="img-fluid rounded-3">
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Paket Layanan Kami</h2>
                <p class="text-muted">Pilih layanan yang sesuai dengan kebutuhan Anda</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="feature-box d-flex flex-column h-100 text-center">
                        <div class="feature-icon mb-3">
                            <i class="fas fa-truck"></i>
                        </div>
                        <h4>Penjemputan Sampah</h4>
                        <p>Jadwalkan penjemputan sampah rumah tangga Anda. Kami akan mengangkut sampah yang sudah dipilah sesuai jadwal yang Anda tentukan.</p>
                        <div class="mt-auto">
                            <a href="#" class="btn btn-primary-custom">Info Selengkapnya</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="feature-box d-flex flex-column h-100 text-center">
                        <div class="feature-icon mb-3">
                            <i class="fas fa-coins"></i>
                        </div>
                        <h4>Tukar Poin</h4>
                        <p>Tukarkan poin hasil pengumpulan sampah menjadi uang tunai.</p>
                        <div class="mt-auto">
                            <a href="#" class="btn btn-primary-custom">Info Selengkapnya</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>