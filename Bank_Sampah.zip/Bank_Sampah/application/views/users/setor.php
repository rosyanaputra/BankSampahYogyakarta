<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">SETOR SAMPAH ANDA</h1>
        <p class="lead">Bank Sampah Digital Yogyakarta</p>
    </div>

    <div class="container">
        <div class="card border-0 shadow-lg p-4 mb-5" style="border-radius: 1rem;">
            <form action="<?php echo site_url('setoran/simpan'); ?>" method="post">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="jenisSampah" class="form-label fw-semibold">Jenis Sampah</label>
                        <select class="form-select" id="jenisSampah" name="jenisSampah" required>
                            <option value="organik">Organik [ bahan alami yang mudah terurai ]</option>
                            <option value="anorganik">Anorganik [ bahan yang sulit terurai ]</option>
                            <option value="B3">Sampah B3 [ Zat berbahaya atau beracun ]</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="berat" class="form-label fw-semibold">Berat (kg)</label>
                        <input type="number" class="form-control" id="berat" name="berat" step="0.01" min="0" required placeholder="Contoh: 2.5">
                    </div>

                    <div class="col-12">
                        <label for="catatan" class="form-label fw-semibold">Catatan (Opsional)</label>
                        <textarea class="form-control" id="catatan" name="catatan" rows="2" placeholder="Contoh: Botol bekas air mineral"></textarea>
                    </div>

                    <div class="col-12">
                        <label for="alamat" class="form-label fw-semibold">Alamat Lokasi Penjemputan</label>
                        <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Ketik atau pilih titik di peta...">
                        <small class="form-text text-muted">Tekan <strong>Enter</strong> setelah mengetik alamat untuk menampilkan lokasi di peta.</small>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Tandai Lokasi Anda di Peta</label>
                        <div id="map" style="height: 300px; border-radius: 12px; overflow: hidden; border: 1px solid #ced4da;"></div>
                    </div>

                    <div class="col-md-6">
                        <label for="latitude" class="form-label fw-semibold">Latitude</label>
                        <input type="text" class="form-control" id="latitude" name="latitude" required readonly>
                    </div>
                    <div class="col-md-6">
                        <label for="longitude" class="form-label fw-semibold">Longitude</label>
                        <input type="text" class="form-control" id="longitude" name="longitude" required readonly>
                    </div>

                    <div class="col-12 mt-4 text-center">
                        <button type="submit" class="btn btn-outline-success btn-lg shadow px-5 py-3 d-inline-flex align-items-center gap-2">
                            <i class="bi bi-recycle fs-4"></i> <span class="fw-bold">Setor Sekarang</span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Tambahan style khusus -->
<style>
    #map {
        transition: all 0.3s ease-in-out;
    }

    select.form-select,
    input.form-control,
    textarea.form-control {
        border-radius: 0.5rem;
    }

    .form-label {
        font-size: 1rem;
    }
</style>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Leaflet CSS & JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
    const defaultLat = -7.7956;
    const defaultLng = 110.3695;

    // Batas wilayah Yogyakarta
    const boundsYogyakarta = L.latLngBounds(
        L.latLng(-7.905, 110.246), // barat daya
        L.latLng(-7.551, 110.505) // timur laut
    );

    const map = L.map('map', {
        maxBounds: boundsYogyakarta,
        maxBoundsViscosity: 1.0,
        minZoom: 12,
        maxZoom: 18
    }).setView([defaultLat, defaultLng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    let marker = L.marker([defaultLat, defaultLng], {
        draggable: true
    }).addTo(map);

    document.getElementById('latitude').value = defaultLat;
    document.getElementById('longitude').value = defaultLng;

    // Fungsi reverse geocode untuk dapatkan alamat dari lat/lng
    function reverseGeocode(lat, lng) {
        const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`;
        fetch(url)
            .then(res => res.json())
            .then(data => {
                if (data && data.display_name) {
                    document.getElementById('alamat').value = data.display_name;
                }
            })
            .catch(error => {
                console.error('Gagal reverse geocode:', error);
            });
    }

    // Gerakkan marker saat digeser
    marker.on('dragend', function(e) {
        const pos = marker.getLatLng();
        document.getElementById('latitude').value = pos.lat.toFixed(6);
        document.getElementById('longitude').value = pos.lng.toFixed(6);
        reverseGeocode(pos.lat, pos.lng);
    });

    // Klik peta untuk pindah marker
    map.on('click', function(e) {
        const {
            lat,
            lng
        } = e.latlng;
        marker.setLatLng([lat, lng]);
        document.getElementById('latitude').value = lat.toFixed(6);
        document.getElementById('longitude').value = lng.toFixed(6);
        reverseGeocode(lat, lng);
    });

    // Manual edit lat/lng input
    document.getElementById('latitude').addEventListener('change', updateMarker);
    document.getElementById('longitude').addEventListener('change', updateMarker);

    function updateMarker() {
        const lat = parseFloat(document.getElementById('latitude').value);
        const lng = parseFloat(document.getElementById('longitude').value);
        if (!isNaN(lat) && !isNaN(lng)) {
            marker.setLatLng([lat, lng]);
            map.setView([lat, lng], 13);
            reverseGeocode(lat, lng);
        }
    }

    // Pencarian alamat terbatas di Yogyakarta
    document.getElementById('alamat').addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            const alamat = this.value;
            if (!alamat) return;

            const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(alamat)}&viewbox=110.2500,-7.5500,110.5000,-7.9000&bounded=1`;

            fetch(url)
                .then(res => res.json())
                .then(data => {
                    if (data.length > 0) {
                        const lat = parseFloat(data[0].lat);
                        const lon = parseFloat(data[0].lon);

                        marker.setLatLng([lat, lon]);
                        map.setView([lat, lon], 15);

                        document.getElementById('latitude').value = lat.toFixed(6);
                        document.getElementById('longitude').value = lon.toFixed(6);
                        document.getElementById('alamat').value = data[0].display_name;
                    } else {
                        alert("Alamat tidak ditemukan di wilayah Yogyakarta.");
                    }
                })
                .catch(error => {
                    console.error(error);
                    alert("Terjadi kesalahan saat mencari lokasi.");
                });
        }
    });

    // Tidak set alamat saat halaman pertama dimuat, biarkan placeholder muncul
</script>