<style>
    .table thead th {
        vertical-align: middle;
    }

    .table tbody td {
        vertical-align: middle;
        background-color: #f9f9f9;
    }

    .table-hover tbody tr:hover {
        background-color: #e8f5e9;
    }
</style>

<div class="main-content py-4">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold display-5">RIWAYAT SETORAN SAMPAH</h1>
        <p class="lead">Bank Sampah Digital Yogyakarta</p>
    </div>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <a href="<?= site_url('user/setor'); ?>" class="btn btn-outline-success d-inline-flex align-items-center gap-2 px-4 py-2">
                <i class="bi bi-upload fs-5"></i> <span class="fw-semibold">Setor Sampah</span>
            </a>
        </div>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i> <?= $this->session->flashdata('success'); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $this->session->flashdata('error'); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive shadow-sm rounded-4 overflow-hidden">
            <table class="table table-hover table-striped table-bordered align-middle mb-0">
                <thead class="table-success text-center text-white" style="background: linear-gradient(135deg, #388e3c, #2e7d32);">
                    <tr>
                        <th>No</th>
                        <th>Jenis Sampah</th>
                        <th>Berat (kg)</th>
                        <th>Alamat</th>
                        <th>Catatan</th>
                        <th>Poin</th>
                        <th>Waktu Setor</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php if (!empty($setoran)): ?>
                        <?php $no = 1;
                        foreach ($setoran as $item): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td class="text-start"><?= htmlspecialchars($item->jenis_sampah); ?></td>
                                <td class="text-end"><?= number_format($item->berat, 2); ?></td>
                                <td class="text-start"><?= htmlspecialchars($item->alamat); ?></td>
                                <td class="text-start"><?= htmlspecialchars($item->catatan ?? '-'); ?></td>
                                <td><?= $item->poin; ?></td>
                                <td><?= date('d M Y, H:i', strtotime($item->created_at)); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">Belum ada data setoran.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>