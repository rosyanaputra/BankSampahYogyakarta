<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">RIWAYAT WITHDRAW</h1>
        <p class="lead">Penarikan saldo poin Anda</p>
    </div>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success text-center"><?= $this->session->flashdata('success'); ?></div>
    <?php elseif ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger text-center"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <a href="<?= site_url('user/saldo'); ?>" class="btn btn-outline-success d-inline-flex align-items-center gap-2 px-4 py-2">
            <i class="bi bi-arrow-left fs-5"></i> <span class="fw-semibold">Kembali ke Saldo</span>
        </a>
    </div>

    <?php if (empty($riwayat)): ?>
        <div class="alert alert-info text-center">Belum ada riwayat withdraw.</div>
    <?php else: ?>
        <div class="table-responsive rounded">
            <table class="table table-bordered table-hover shadow-sm bg-white">
                <thead class="table-success text-center">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Poin</th>
                        <th>Jumlah (Rp)</th>
                        <th>Bank</th>
                        <th>No. Rekening</th>
                        <th>Atas Nama</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php foreach ($riwayat as $i => $row): ?>
                        <tr>
                            <td><?= $i + 1; ?></td>
                            <td><?= date('d-m-Y H:i', strtotime($row->created_at)) ?></td>
                            <td><?= number_format($row->poin); ?></td>
                            <td>Rp <?= number_format($row->poin * 100, 0, ',', '.'); ?></td>
                            <td><?= htmlspecialchars($row->bank); ?></td>
                            <td><?= htmlspecialchars($row->no_rekening); ?></td>
                            <td><?= htmlspecialchars($row->nama_rekening); ?></td>
                            <td>
                                <span class="badge bg-<?= $row->status == 'Diproses' ? 'warning' : ($row->status == 'Sukses' ? 'success' : 'danger'); ?>">
                                    <?= $row->status; ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

</div>