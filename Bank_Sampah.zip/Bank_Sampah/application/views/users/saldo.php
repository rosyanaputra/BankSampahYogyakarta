<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">SALDO POINT ANDA</h1>
        <p class="lead">Bank Sampah Digital Yogyakarta</p>
    </div>

    <div class="row justify-content-center mb-4">
        <div class="col-md-6">
            <div class="card shadow text-center border-success">
                <div class="card-body">
                    <h5 class="card-title text-muted">TOTAL POINT ANDA</h5>
                    <div class="display-4 fw-bold text-success mb-3">
                        <i class="bi bi-currency-exchange me-2"></i>
                        <?= isset($saldo->poin) ? number_format($saldo->poin, 0, ',', '.') : '0'; ?> Point
                    </div>
                    <p class="text-muted">Tukar poin Anda menjadi uang tunai. 1 Poin = Rp100</p>

                    <div class="text-center mt-4">
                        <a href="<?= site_url('user/riwayat_withdraw'); ?>" class="btn btn-outline-secondary d-inline-flex align-items-center gap-2 px-4 py-2">
                            <i class="bi bi-clock-history fs-5"></i> <span class="fw-semibold">Lihat Riwayat Withdraw</span>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="<?= base_url('user/withdraw'); ?>" method="get" class="shadow p-4 rounded bg-light border">
                <div class="mb-3">
                    <label for="poin" class="form-label">Jumlah Poin yang Ingin Ditukar</label>
                    <input type="number" name="poin" id="poin-input" class="form-control" required min="300" max="<?= $saldo->poin ?? 0; ?>">
                    <small class="form-text text-muted">Minimal penukaran 300 poin</small>
                </div>

                <div class="mb-3">
                    <label for="estimasi" class="form-label">Estimasi Uang Tunai</label>
                    <input type="text" id="estimasi-rupiah" class="form-control" readonly value="Rp 0">
                </div>

                <input type="hidden" name="jenis" value="Uang Tunai">

                <button type="submit" class="btn btn-outline-success w-100">Tukar Sekarang</button>
            </form>
        </div>
    </div>
</div>

<script>
    const poinInput = document.getElementById('poin-input');
    const estimasiInput = document.getElementById('estimasi-rupiah');

    poinInput.addEventListener('input', function() {
        const poin = parseInt(this.value) || 0;
        const rupiah = poin * 100;
        estimasiInput.value = "Rp " + rupiah.toLocaleString('id-ID');
    });
</script>