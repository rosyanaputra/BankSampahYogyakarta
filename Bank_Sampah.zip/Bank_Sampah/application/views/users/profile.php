<div class="main-content mb-5">

    <div class="hero text-center mb-5">
        <h1 class="fw-bold">PROFILE ANDA</h1>
        <p class="lead">Bank Sampah Digital Yogyakarta</p>
    </div>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success"><?= $this->session->flashdata('success'); ?></div>
    <?php elseif ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <div class="card shadow border-0 mx-auto p-4" style="max-width: 900px; border-radius: 16px;">
        <div class="row g-4">

            <div class="text-center mb-4">
                <img src="<?= base_url('asset/uploads/foto_profile/' . $user->foto); ?>" class="rounded-circle mt-1" width="150" height="150" style="object-fit: cover;">
            </div>


            <div class="col-md-6">
                <label for="username" class="form-label fw-semibold">Username</label>
                <input type="text" id="username" class="form-control" value="<?= $user->username ?>" readonly>
            </div>

            <div class="col-md-6">
                <label for="nama_lengkap" class="form-label fw-semibold">Nama Lengkap</label>
                <input type="text" id="nama_lengkap" class="form-control" value="<?= $user->nama_lengkap ?>" readonly>
            </div>

            <div class="col-md-6">
                <label for="email" class="form-label fw-semibold">Email</label>
                <input type="email" id="email" class="form-control" value="<?= $user->email ?>" readonly>
            </div>

            <div class="col-md-6">
                <label for="no_hp" class="form-label fw-semibold">No HP</label>
                <input type="text" id="no_hp" class="form-control" value="<?= $user->no_hp ?>" readonly>
            </div>

            <div class="col-md-12">
                <label for="alamat" class="form-label fw-semibold">Alamat</label>
                <textarea id="alamat" class="form-control" rows="3" readonly><?= $user->alamat ?></textarea>
            </div>

            <div class="col-12 text-center mt-4">
                <a href="<?= site_url('user/edit_profile'); ?>"
                    class="btn btn-outline-success rounded-pill px-4 py-2 d-inline-flex align-items-center fs-6">
                    <i class="bi bi-pencil-square me-2 fs-5 align-middle"></i>
                    <span class="align-middle">Edit Profile</span>
                </a>
            </div>

        </div>
    </div>
</div>