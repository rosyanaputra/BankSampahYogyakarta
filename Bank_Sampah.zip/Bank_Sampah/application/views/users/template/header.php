<!-- File: application/views/user/dashboard.php -->
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pengguna | Bank Sampah Digital Yogyakarta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f8;
        }

        .sidebar {
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            background-color: #198754;
            color: #fff;
            padding-top: 1rem;
            overflow-y: auto;
        }

        .sidebar a {
            color: #fff;
            padding: 10px 20px;
            display: block;
            text-decoration: none;
        }

        .sidebar a:hover {
            background-color: #157347;
        }

        .main-content {
            margin-left: 250px;
            padding: 2rem;
        }

        .main-content-footer {
            margin-left: 250px;
        }

        .card {
            border: none;
            border-radius: 1rem;
            transition: transform 0.2s;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .card:hover {
            transform: scale(1.02);
        }

        .hero {
            background: linear-gradient(120deg, #198754, #28a745);
            color: white;
            padding: 2rem;
            border-radius: 1rem;
        }

        .bi {
            font-size: 2rem;
        }

        .saldo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }

        .saldo-container i {
            cursor: pointer;
            font-size: 1.25rem;
        }

        .btn-xs-custom {
            padding: 0.3rem 0.6rem;
            font-size: 0.9rem;
            line-height: 1.1;
            border-radius: 0.25rem;
        }

        .btn-xs-custom .small-icon {
            font-size: 0.85rem;
            line-height: 1;
        }

        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #198754;
            overflow-y: auto;
            transition: all 0.3s ease;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .sidebar a.nav-link {
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease;
        }

        .sidebar a.nav-link:hover {
            background-color: #157347;
            text-decoration: none;
        }

        .sidebar .active {
            background-color: #145f43;
        }
    </style>
</head>

<body>
    <!-- Sidebar - Bisa ditempatkan di partials/header.php -->
    <div class="sidebar d-flex flex-column align-items-center text-white p-3 shadow">
        <!-- Logo / Judul -->
        <div class="mb-4 text-center">
            <img src="<?= base_url('asset/img/logo_2_bg_white.png') ?>" alt="Logo Bank Sampah" width="100" class="mb-2 rounded">
        </div>

        <!-- Profil User -->
        <div class="d-flex align-items-center gap-2 mb-4 bg-success p-2 rounded shadow-sm" style="width: 100%;">
            <img src="<?= base_url('asset/uploads/foto_profile/' . $this->session->userdata('foto')) ?>"
                alt="Foto Profil" class="rounded-circle border" width="45" height="45">
            <div class="flex-grow-1">
                <p class="mb-0 fw-semibold"><?= $this->session->userdata('username'); ?></p>
                <small class="text-light d-flex align-items-center gap-1">
                    <span class="rounded-circle border border-white" style="background-color: #28a745; width: 10px; height: 10px; display: inline-block;"></span>
                    User Aktif
                </small>
            </div>
        </div>

        <!-- Navigasi -->
        <nav class="w-100">
            <a href="<?= site_url('user/dashboard'); ?>" class="nav-link <?= $this->uri->segment(2) == 'dashboard' ? 'active' : '' ?> text-white mb-2 d-flex align-items-center">
                <i class="bi bi-house me-2"></i> Beranda
            </a>
            <a href="<?= site_url('user/setor'); ?>" class="nav-link <?= $this->uri->segment(2) == 'setor' ? 'active' : '' ?> text-white mb-2 d-flex align-items-center">
                <i class="bi bi-recycle me-2"></i> Setor Sampah
            </a>
            <a href="<?= site_url('user/saldo'); ?>" class="nav-link <?= $this->uri->segment(2) == 'saldo' ? 'active' : '' ?> text-white mb-2 d-flex align-items-center">
                <i class="bi bi-cash me-2"></i> Saldo
            </a>
            <a href="<?= site_url('user/profile'); ?>" class="nav-link <?= $this->uri->segment(2) == 'profile' ? 'active' : '' ?> text-white mb-2 d-flex align-items-center">
                <i class="bi bi-person me-2"></i> Profil Saya
            </a>
            <a href="<?= site_url('auth/logout'); ?>" class="nav-link <?= $this->uri->segment(2) == 'logout' ? 'active' : '' ?> text-white mb-2 d-flex align-items-center" onclick="return confirm('Yakin ingin keluar?')">
                <i class="bi bi-box-arrow-right me-2"></i> Keluar
            </a>
        </nav>
    </div>