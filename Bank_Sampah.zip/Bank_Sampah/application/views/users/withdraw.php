<?php
$poin = isset($_GET['poin']) ? (int) $_GET['poin'] : 0;
$estimasi = $poin * 100;
?>

<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">WITHDRAW POINT ANDA</h1>
        <p class="lead">Bank Sampah Digital Yogyakarta</p>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow border-0">
                <div class="card-body p-4">

                    <form method="post" action="<?= base_url('user/withdraw'); ?>">
                        <div class="mb-3">
                            <label for="poin" class="form-label fw-semibold">Jumlah Poin</label>
                            <input type="number" name="poin" id="poin" class="form-control" min="300" max="<?= $saldo->poin ?? 0; ?>" required value="<?= $poin; ?>">
                            <small class="text-muted">Minimal penukaran 300 poin (1 poin = Rp100)</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Estimasi Uang Diterima</label>
                            <input type="text" id="estimasi" class="form-control bg-light" readonly value="Rp <?= number_format($estimasi, 0, ',', '.'); ?>">
                        </div>

                        <hr class="my-4">

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Bank</label>
                            <input type="text" name="bank" class="form-control" placeholder="Contoh: BCA, BRI" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nomor Rekening</label>
                            <input type="text" name="no_rekening" class="form-control" placeholder="Masukkan nomor rekening" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Pemilik Rekening</label>
                            <input type="text" name="nama_rekening" class="form-control" placeholder="Nama lengkap sesuai rekening" required>
                        </div>

                        <button type="submit" class="btn btn-success w-100 fw-bold">Ajukan Withdraw</button>
                    </form>
                </div>
            </div>

            <!-- Notifikasi Berhasil / Gagal -->
            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show mt-3 text-center" role="alert">
                    <?= $this->session->flashdata('success'); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php elseif ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show mt-3 text-center" role="alert">
                    <?= $this->session->flashdata('error'); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    const poinInput = document.getElementById('poin');
    const estimasiOutput = document.getElementById('estimasi');

    poinInput.addEventListener('input', function() {
        const poin = parseInt(this.value) || 0;
        const rupiah = poin * 100;
        estimasiOutput.value = "Rp " + rupiah.toLocaleString('id-ID');
    });
</script>