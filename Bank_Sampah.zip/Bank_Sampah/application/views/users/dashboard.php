<div class="main-content py-5 px-3" style="background: linear-gradient(to right, #e0f7ec, #f4fefb); min-height: 100vh;">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold display-5">Selamat Datang di Bank Sampah Digital</h1>
        <p class="lead">🌿 Kelola sampah, kumpulkan poin, dan bantu ciptakan Yogyakarta yang bersih & hijau 🌿</p>
    </div>

    <div class="text-center mb-5">
        <a href="<?= site_url('user/setor'); ?>" class="btn btn-success btn-lg shadow px-5 py-3">
            <i class="bi bi-upload me-2"></i> SETOR SAMPAH SEKARANG
        </a>
    </div>

    <div class="row g-4">
        <!-- Kartu 1 -->
        <div class="col-md-4 d-flex">
            <div class="card text-center shadow-lg p-4 w-100 border-0" style="border-radius: 20px; background: rgba(255,255,255,0.85); backdrop-filter: blur(10px); transition: 0.3s;">
                <div>
                    <i class="bi bi-recycle display-4 text-success mb-3"></i>
                    <h5 class="fw-semibold">Total Setoran</h5>
                    <h2 class="text-success fw-bold"><?= number_format($total_berat, 2); ?> Kg</h2>
                    <p class="text-muted">Total berat sampah yang telah kamu setor.</p>
                </div>
                <a href="<?= site_url('user/riwayat'); ?>" class="btn btn-outline-success mt-3">Lihat Riwayat</a>
            </div>
        </div>

        <!-- Kartu 2 -->
        <div class="col-md-4 d-flex">
            <div class="card text-center shadow-lg p-4 w-100 border-0" style="border-radius: 20px; background: rgba(255,255,255,0.85); backdrop-filter: blur(10px); transition: 0.3s;">
                <div>
                    <i class="bi bi-wallet2 display-4 text-success mb-3"></i>
                    <h5 class="fw-semibold">Saldo Poin</h5>
                    <div class="saldo-container d-flex justify-content-center align-items-center gap-2">
                        <h2 class="text-success fw-bold" id="saldo-nominal"><?= number_format($poin); ?></h2>
                        <span class="fw-semibold text-muted">Point</span>
                        <i class="bi bi-eye-slash" id="toggle-saldo" role="button"></i>
                    </div>
                    <p class="text-muted">Poin yang kamu kumpulkan dari penukaran sampah.</p>
                </div>
                <a href="<?= site_url('user/saldo'); ?>" class="btn btn-outline-success mt-3">Lihat Saldo</a>
            </div>
        </div>

        <!-- Kartu 3 -->
        <div class="col-md-4 d-flex">
            <div class="card text-center shadow-lg p-4 w-100 border-0" style="border-radius: 20px; background: rgba(255,255,255,0.85); backdrop-filter: blur(10px); transition: 0.3s;">
                <div>
                    <i class="bi bi-people-fill display-4 text-success mb-3"></i>
                    <h5 class="fw-semibold">Komunitas</h5>
                    <p class="text-muted">Gabung komunitas bank sampah terdekat di lingkunganmu.</p>
                </div>
                <a href="#" class="btn btn-outline-success mt-3">Gabung Sekarang</a>
            </div>
        </div>
    </div>
</div>

<!-- Toggle Saldo -->
<script>
    const toggleIcon = document.getElementById('toggle-saldo');
    const saldoSpan = document.getElementById('saldo-nominal');
    let visible = true;

    toggleIcon.addEventListener('click', () => {
        visible = !visible;
        if (visible) {
            saldoSpan.textContent = '<?= number_format($poin); ?>';
            toggleIcon.classList.remove('bi-eye');
            toggleIcon.classList.add('bi-eye-slash');
        } else {
            saldoSpan.textContent = '••••••';
            toggleIcon.classList.remove('bi-eye-slash');
            toggleIcon.classList.add('bi-eye');
        }
    });
</script>