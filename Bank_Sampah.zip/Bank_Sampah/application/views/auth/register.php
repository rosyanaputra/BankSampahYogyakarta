<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register | Bank Sampah Digital Yogyakarta</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

    <style>
        :root {
            --primary-color: #2e7d32;
            --secondary-color: #7cb342;
            --accent-color: #c8e6c9;
            --dark-color: #1b5e20;
            --light-color: #f1f8e9;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(rgba(46, 125, 50, 0.9), rgba(46, 125, 50, 0.9));
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .register-container {
            max-width: 500px;
            width: 90%;
            padding: 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            border-top: 5px solid var(--secondary-color);
        }

        .register-container h3 {
            color: var(--dark-color);
        }

        .form-control {
            border-radius: 0.5rem;
        }

        .btn-success {
            background-color: var(--dark-color);
            border: none;
            border-radius: 0.5rem;
            padding: 10px;
        }

        .btn-success:hover {
            background-color: var(--secondary-color);
        }

        .text-link {
            color: var(--primary-color);
            text-decoration: none;
        }

        .text-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .register-container {
                padding: 1.5rem;
            }
        }

        .back-btn-inside {
            border-radius: 50%;
            width: 40px;
            height: 40px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            background-color: var(--light-color);
            color: var(--dark-color);
            border: 1px solid var(--dark-color);
            transition: all 0.2s ease-in-out;
            margin-bottom: 15px;
        }

        .back-btn-inside:hover {
            background-color: var(--secondary-color);
            color: white;
            border-color: var(--secondary-color);
        }
    </style>
</head>

<body>
    <!-- Register Container -->
    <div class="register-container text-center">
        <div class="text-start">
            <a href="<?php echo base_url('landing_page'); ?>" class="btn btn-outline-secondary back-btn-inside" title="Kembali ke Beranda">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>

        <img src="<?php echo base_url('asset/img/logo_2.png'); ?>" alt="Logo" class="mb-4 mx-auto d-block" style="max-height: 80px;">
        <h3 class="mb-4">Buat Akun Baru</h3>

        <?php if (validation_errors()) : ?>
            <div class="alert alert-danger"><?php echo validation_errors(); ?></div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('success')) : ?>
            <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
        <?php endif; ?>


        <form action="<?php echo base_url('auth/register'); ?>" method="post">
            <div class="mb-3 text-start">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required />
            </div>

            <div class="mb-3 text-start">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required />
            </div>

            <div class="mb-3 text-start">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required />
            </div>

            <div class="mb-3 text-start">
                <label for="konfirmasi_password" class="form-label">Konfirmasi Password</label>
                <input type="password" class="form-control" id="konfirmasi_password" name="konfirmasi_password" required />
            </div>

            <div class="d-grid mt-4 mb-3">
                <button type="submit" class="btn btn-success">DAFTAR</button>
            </div>
        </form>

        <p class="mb-0">Sudah punya akun?
            <a href="<?php echo base_url('auth/login'); ?>" class="text-link">Login di sini</a>
        </p>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>