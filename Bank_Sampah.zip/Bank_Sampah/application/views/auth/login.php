<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Bank Sampah Digital Yogyakarta</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #2e7d32;
            --secondary-color: #7cb342;
            --dark-color: #1b5e20;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(rgba(46, 125, 50, 0.9), rgba(46, 125, 50, 0.9));
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        :root {
            --primary-color: #2e7d32;
            --secondary-color: #7cb342;
            --accent-color: #c8e6c9;
            --dark-color: #1b5e20;
            --light-color: #f1f8e9;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: #333;
            overflow-x: hidden;
        }

        .navbar-brand img {
            height: 40px;
        }

        .hero-section {
            background: linear-gradient(rgba(46, 125, 50, 0.8), rgba(46, 125, 50, 0.8)),
                url('https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/9e7bb695-6c8a-4963-b67f-ea6bc80f4342.png') no-repeat center center;
            background-size: cover;
            color: white;
            padding: 120px 0 80px;
            position: relative;
        }

        .hero-section h1 {
            font-weight: 700;
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .hero-section p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
        }

        .btn-primary-custom {
            background-color: var(--light-color);
            color: var(--dark-color);
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 50px;
            transition: all 0.3s;
        }

        .btn-primary-custom:hover {
            background-color: var(--accent-color);
            transform: translateY(-3px);
        }

        .footer {
            background-color: var(--dark-color);
            color: white;
            padding: 60px 0 20px;
        }

        .footer a {
            color: var(--accent-color);
            text-decoration: none;
        }

        .footer a:hover {
            color: white;
        }

        .social-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            transition: all 0.3s;
        }

        .social-icon:hover {
            background-color: var(--secondary-color);
            transform: translateY(-3px);
        }


        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2.2rem;
            }

            .hero-section p {
                font-size: 1rem;
            }
        }

        .login-container {
            max-width: 400px;
            width: 90%;
            margin: auto;
            padding: 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            border-top: 5px solid var(--secondary-color);
        }

        .login-container h3 {
            color: var(--dark-color);
        }

        .login-icon {
            font-size: 3rem;
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 25px;
        }

        .back-btn-inside {
            border-radius: 50%;
            width: 40px;
            height: 40px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            background-color: var(--light-color);
            color: var(--dark-color);
            border: 1px solid var(--dark-color);
            transition: all 0.2s ease-in-out;
            margin-bottom: 15px;
        }

        .back-btn-inside:hover {
            background-color: var(--secondary-color);
            color: white;
            border-color: var(--secondary-color);
        }
    </style>
</head>

<body>
    <!-- Login Container -->
    <div class="container">
        <div class="login-container text-center">
            <div class="text-start">
                <a href="<?php echo base_url('landing_page'); ?>" class="btn btn-outline-secondary back-btn-inside" title="Kembali ke Beranda">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            <img src="<?php echo base_url('asset/img/logo_2.png'); ?>" alt="Logo" class="mb-4 mx-auto d-block" style="max-height: 80px;">
            <h3 class="mb-4">Login Akun</h3>

            <?php if ($this->session->flashdata('error')) : ?>
                <div class="alert alert-danger">
                    <?= $this->session->flashdata('error'); ?>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('success')) : ?>
                <div class="alert alert-success">
                    <?= $this->session->flashdata('success'); ?>
                </div>
            <?php endif; ?>

            <form action="<?php echo base_url('auth/login'); ?>" method="post">
                <div class="mb-3">
                    <input type="email" class="form-control" placeholder="Email" name="email" required>
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" placeholder="Password" name="password" required>
                </div>
                <div class="d-flex justify-content-between mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="remember">
                        <label class="form-check-label" for="remember">Ingat saya</label>
                    </div>
                    <a href="#" class="text-success">Lupa password?</a>
                </div>
                <button type="submit" class="btn btn-success w-100 py-2 mb-3">LOGIN</button>
            </form>

            <hr>
            <p class="mb-0">Belum punya akun? <a href="<?php echo base_url('auth/register'); ?>" class="text-success">Daftar sekarang</a></p>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Additional JS -->
    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
            } else {
                navbar.style.boxShadow = 'none';
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Animation on scroll
        const animateOnScroll = function() {
            const elements = document.querySelectorAll('.feature-box, .step-card, .testimonial-card');
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;

                if (elementPosition < windowHeight - 100) {
                    element.classList.add('animate__animated', 'animate__fadeInUp');
                }
            });
        };

        window.addEventListener('scroll', animateOnScroll);
        animateOnScroll(); // Run once on page load
    </script>

</body>

</html>