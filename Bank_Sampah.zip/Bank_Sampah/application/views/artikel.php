    <style>
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }

        .card {
            min-height: 100%;
        }
    </style>

    <!-- About Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="animate__animated animate__fadeInDown">Tentang Bank Sampah Digital Yogyakarta</h1>
            <p class="animate__animated animate__fadeInUp">Mengubah cara masyarakat Yogyakarta mengelola sampah sejak 2019 dengan inovasi teknologi dan komitmen lingkungan.</p>
            <div class="mt-5">
                <img src="<?php echo base_url('asset/img/artikel.jpeg'); ?>" alt="Team photo of Bank Sampah Digital Yogyakarta staff in green uniforms" class="img-fluid rounded-3">
            </div>
        </div>
    </section>


    <!-- Articles Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Artikel Terbaru</h2>
                <p class="text-muted">Temukan tips dan informasi terkini tentang pengelolaan sampah</p>
            </div>

            <div id="artikelCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php if (!empty($articles)): ?>
                        <?php
                        $chunked_articles = array_chunk($articles, 3);
                        foreach ($chunked_articles as $index => $chunk):
                        ?>
                            <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                <div class="row g-4">
                                    <?php foreach ($chunk as $article): ?>
                                        <div class="col-md-4">
                                            <div class="card h-100 d-flex flex-column border-0 shadow-sm">
                                                <img src="<?php echo $article['urlToImage'] ?: 'https://via.placeholder.com/600x400?text=No+Image'; ?>" class="card-img-top" alt="Artikel Terkait">
                                                <div class="card-body flex-grow-1">
                                                    <span class="badge bg-success mb-2">Lingkungan</span>
                                                    <h5 class="card-title fw-bold"><?php echo $article['title']; ?></h5>
                                                    <p class="card-text text-muted">
                                                        <?php echo mb_strimwidth($article['description'] ?? $article['content'], 0, 120, "..."); ?>
                                                    </p>
                                                </div>
                                                <div class="card-footer bg-transparent mt-auto">
                                                    <a href="<?php echo $article['url']; ?>" target="_blank" class="btn btn-primary-custom w-100">Baca Selengkapnya</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-center">Tidak ada artikel yang tersedia saat ini.</p>
                    <?php endif; ?>
                </div>

                <!-- Tombol Carousel -->
                <?php if (count($articles) > 3): ?>
                    <button class="carousel-control-prev" type="button" data-bs-target="#artikelCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Sebelumnya</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#artikelCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Selanjutnya</span>
                    </button>
                <?php endif; ?>
            </div>

            <!-- Tombol Custom -->
            <?php if (count($articles) > 3): ?>
                <div class="d-flex justify-content-center mt-4 gap-3">
                    <button class="btn btn-outline-secondary rounded-pill px-4" type="button" data-bs-target="#artikelCarousel" data-bs-slide="prev">
                        ← Artikel Sebelumnya
                    </button>
                    <button class="btn btn-outline-success rounded-pill px-4" type="button" data-bs-target="#artikelCarousel" data-bs-slide="next">
                        Artikel Selanjutnya →
                    </button>
                </div>
            <?php endif; ?>

        </div>
    </section>