    <!-- Contact Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="animate__animated animate__fadeInDown">Hubungi Kami</h1>
            <p class="animate__animated animate__fadeInUp">Kami selalu siap membantu Anda untuk segala pertanyaan seputar Bank Sampah Digital</p>
            <div class="mt-5">
                <img src="<?php echo base_url('asset/img/kontak.jpeg'); ?>" alt="Customer service illustration with people using digital devices" class="img-fluid rounded-3">
            </div>
        </div>
    </section>


    <!-- Articles Section -->
    <!-- Contact Form Section -->
    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h2 class="fw-bold mb-4">Kirim Pesan</h2>
                            <?php if ($this->session->flashdata('success')): ?>
                                <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('error')): ?>
                                <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
                            <?php endif; ?>
                            <form action="<?php echo site_url('kontak/send_message'); ?>" method="post">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Nomor Telepon</label>
                                    <input type="tel" class="form-control" id="phone" name="phone">
                                </div>
                                <div class="mb-3">
                                    <label for="message" class="form-label">Pesan Anda</label>
                                    <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary-custom">Kirim Pesan</button>
                            </form>


                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h2 class="fw-bold mb-4">Informasi Kontak</h2>
                            <div class="contact-info">
                                <div class="d-flex mb-4">
                                    <i class="fas fa-map-marker-alt text-success me-3" style="font-size: 1.5rem;"></i>
                                    <div>
                                        <h5>Alamat Kantor</h5>
                                        <p>Jl. Kenari No. 45, Yogyakarta 55281</p>
                                    </div>
                                </div>
                                <div class="d-flex mb-4">
                                    <i class="fas fa-phone-alt text-success me-3" style="font-size: 1.5rem;"></i>
                                    <div>
                                        <h5>Telepon</h5>
                                        <p>(0274) 555-1234</p>
                                    </div>
                                </div>
                                <div class="d-flex mb-4">
                                    <i class="fas fa-envelope text-success me-3" style="font-size: 1.5rem;"></i>
                                    <div>
                                        <h5>Email</h5>
                                        <p>info@banksampahjogja.id</p>
                                    </div>
                                </div>
                                <div class="d-flex">
                                    <i class="fas fa-clock text-success me-3" style="font-size: 1.5rem;"></i>
                                    <div>
                                        <h5>Jam Operasional</h5>
                                        <p>Senin-Sabtu, 08:00-16:00 WIB</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->