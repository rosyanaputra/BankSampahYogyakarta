<?php // File: application/views/admin/withdraw.php 
?>
<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">Data Withdraw Pengguna</h1>
        <p class="lead">Pantau dan kelola permintaan withdraw dari pengguna</p>
    </div>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success text-center"><?= $this->session->flashdata('success'); ?></div>
    <?php elseif ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger text-center"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <div class="table-responsive bg-white p-3 rounded shadow-sm">
        <table class="table table-bordered table-hover text-center align-middle">
            <thead class="table-success">
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Bank</th>
                    <th>No Rekening</th>
                    <th>Atas Nama</th>
                    <th>Poin</th>
                    <th>Jumlah (Rp)</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($withdraws)): ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted">Belum ada data withdraw</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($withdraws as $i => $row): ?>
                        <tr>
                            <td><?= $i + 1; ?></td>
                            <td><?= htmlspecialchars($row->username); ?></td>
                            <td><?= htmlspecialchars($row->bank); ?></td>
                            <td><?= htmlspecialchars($row->no_rekening); ?></td>
                            <td><?= htmlspecialchars($row->nama_rekening); ?></td>
                            <td><?= number_format((float) $row->poin); ?></td>
                            <td>Rp <?= number_format((float) $row->rupiah, 0, ',', '.'); ?></td>
                            <td>
                                <span class="badge bg-<?= $row->status == 'pending' ? 'warning' : ($row->status == 'success' ? 'success' : 'secondary'); ?>">
                                    <?= ucfirst($row->status); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($row->status == 'pending'): ?>
                                    <a href="<?= site_url('admin/konfirmasi_withdraw/' . $row->id); ?>" class="btn btn-sm btn-success" onclick="return confirm('Konfirmasi withdraw ini?')">
                                        Konfirmasi
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">Sudah diproses</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>