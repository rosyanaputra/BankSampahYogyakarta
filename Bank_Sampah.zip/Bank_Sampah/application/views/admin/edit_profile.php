<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">EDIT PROFIL ANDA</h1>
        <p class="lead">Bank Sampah Digital Yogyakarta</p>
    </div>

    <div class="card shadow-lg p-4">
        <form action="<?= base_url('admin/edit_profile'); ?>" method="post" enctype="multipart/form-data">

            <div class="col-md-12 mb-3 text-center">
                <label for="foto" class="form-label fw-semibold d-block">Foto Profil</label>
                <img src="<?= base_url('asset/uploads/foto_profile/' . ($user->foto ?? 'default.png')) ?>" class="rounded-circle mb-2" width="120" height="120" style="object-fit: cover;">
                <input type="file" name="foto" class="form-control mt-2" accept="image/*">
            </div>

            <div class="row">
                <!-- Username -->
                <div class="col-md-6 mb-3">
                    <label for="username" class="form-label fw-semibold">
                        Username
                    </label>
                    <input type="text" class="form-control" name="username" value="<?= $user->username ?>" required>
                </div>

                <!-- Nama Lengkap -->
                <div class="col-md-6 mb-3">
                    <label for="nama_lengkap" class="form-label fw-semibold">
                        Nama Lengkap
                    </label>
                    <input type="text" class="form-control" name="nama_lengkap" value="<?= $user->nama_lengkap ?>" required>
                </div>

                <!-- Email -->
                <div class="col-md-6 mb-3">
                    <label for="email" class="form-label fw-semibold">
                        Email
                    </label>
                    <input type="email" class="form-control" name="email" value="<?= $user->email ?>" required>
                </div>

                <!-- No HP -->
                <div class="col-md-6 mb-3">
                    <label for="no_hp" class="form-label fw-semibold">
                        No HP
                    </label>
                    <input type="text" class="form-control" name="no_hp" value="<?= $user->no_hp ?>" required>
                </div>

                <!-- Alamat -->
                <div class="col-md-12 mb-3">
                    <label for="alamat" class="form-label fw-semibold">
                        Alamat
                    </label>
                    <textarea name="alamat" class="form-control" rows="3" required><?= $user->alamat ?></textarea>
                </div>
            </div>

            <hr class="my-4">

            <h5 class="mb-3"> Ganti Password (Opsional)</h5>
            <div class="row">
                <!-- Password -->
                <div class="col-md-6 mb-3">
                    <label for="password" class="form-label fw-semibold">Password Baru</label>
                    <input type="password" class="form-control" name="password" placeholder="Kosongkan jika tidak ingin mengubah">
                </div>

                <!-- Confirm Password -->
                <div class="col-md-6 mb-3">
                    <label for="confirm_password" class="form-label fw-semibold">Konfirmasi Password Baru</label>
                    <input type="password" class="form-control" name="confirm_password" placeholder="Ulangi password baru">
                </div>
            </div>

            <div class="text-center mt-4">
                <button type="submit" class="btn btn-success btn-sm px-3 d-inline-flex align-items-center gap-2">
                    <i class="bi bi-save"></i>
                    <span>Simpan</span>
                </button>
                <a href="<?= site_url('admin/profile'); ?>" class="btn btn-secondary btn-sm px-3 d-inline-flex align-items-center gap-2 ms-2">
                    <i class="bi bi-arrow-left-circle"></i>
                    <span>Batal</span>
                </a>
            </div>

        </form>
    </div>
</div>