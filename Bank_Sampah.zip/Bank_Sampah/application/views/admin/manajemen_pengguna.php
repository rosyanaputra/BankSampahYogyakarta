<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">Manajemen Pengguna</h1>
        <p class="lead">Kelola data seluruh pengguna sistem</p>
    </div>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success text-center"><?= $this->session->flashdata('success'); ?></div>
    <?php elseif ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger text-center"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <div class="table-responsive shadow-sm bg-white p-3 rounded">
        <table class="table table-hover table-bordered align-middle text-center">
            <thead class="table-success">
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Username</th>
                    <th>Nama Lengkap</th>
                    <th>Email</th>
                    <th>No HP</th>
                    <th>Alamat</th>
                    <th>Tanggal Daftar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $i => $user): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td>
                            <img src="<?= base_url('asset/uploads/foto_profile/' . $user->foto) ?>" width="45" height="45" class="rounded-circle border">
                        </td>
                        <td><?= htmlspecialchars($user->username) ?></td>
                        <td><?= htmlspecialchars($user->nama_lengkap) ?></td>
                        <td><?= htmlspecialchars($user->email) ?></td>
                        <td><?= htmlspecialchars($user->no_hp) ?></td>
                        <td><?= htmlspecialchars($user->alamat) ?></td>
                        <td><?= date('d-m-Y H:i', strtotime($user->created_at)) ?></td>
                        <td>
                            <a href="<?= site_url('admin/hapus_pengguna/' . $user->id); ?>"
                                class="btn btn-sm btn-outline-danger d-flex align-items-center justify-content-center gap-1 mx-auto px-3 py-1" style="min-width: 90px;"
                                onclick="return confirm('Yakin ingin menghapus pengguna ini?')">
                                <i class="bi bi-trash"></i> Hapus
                            </a>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>