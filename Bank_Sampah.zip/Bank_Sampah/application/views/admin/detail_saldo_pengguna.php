<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">Detail Saldo Pengguna</h1>
        <p class="lead">Informasi lengkap saldo dan transaksi pengguna</p>
    </div>

    <div class="mb-4">
        <a href="<?= site_url('admin/saldo_pengguna'); ?>" class="btn btn-success d-inline-flex align-items-center gap-2 shadow-sm px-4 py-2">
            <i class="bi bi-arrow-left-circle-fill fs-5"></i>
            <span>Kembali ke Daftar Saldo</span>
        </a>
    </div>


    <!-- Informasi Pengguna -->
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <h5 class="card-title mb-4">Informasi Pengguna</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <strong>Username:</strong><br>
                    <?= htmlspecialchars($user->username); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <strong>Nama Lengkap:</strong><br>
                    <?= htmlspecialchars($user->nama_lengkap); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <strong>Email:</strong><br>
                    <?= htmlspecialchars($user->email); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <strong>No HP:</strong><br>
                    <?= htmlspecialchars($user->no_hp); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <strong>Alamat:</strong><br>
                    <?= nl2br(htmlspecialchars($user->alamat)); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <strong>Saldo Poin Saat Ini:</strong><br>
                    <?= number_format($saldo->poin); ?> poin<br>
                    <small class="text-muted">≈ Rp <?= number_format($saldo->poin * 100, 0, ',', '.'); ?></small>
                </div>
            </div>
        </div>
    </div>


    <!-- Riwayat Setoran -->
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <h5 class="card-title">Riwayat Setoran Sampah</h5>
            <?php if (empty($riwayat_setor)): ?>
                <div class="alert alert-info text-center">Belum ada riwayat setoran.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered text-center align-middle">
                        <thead class="table-success">
                            <tr>
                                <th>No</th>
                                <th>Jenis Sampah</th>
                                <th>Berat (kg)</th>
                                <th>Poin</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($riwayat_setor as $i => $s): ?>
                                <tr>
                                    <td><?= $i + 1; ?></td>
                                    <td><?= htmlspecialchars($s->jenis_sampah); ?></td>
                                    <td><?= number_format($s->berat, 2); ?></td>
                                    <td><?= number_format($s->poin); ?></td>
                                    <td><?= date('d-m-Y H:i', strtotime($s->created_at)); ?></td>
                                    <td><span class="badge bg-<?=
                                                                $s->status == 'selesai' ? 'success' : ($s->status == 'sedang diproses' ? 'warning' : 'secondary') ?>">
                                            <?= $s->status; ?></span></td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
            <?php endif ?>
        </div>
    </div>

    <!-- Riwayat Withdraw -->
    <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="card-title">Riwayat Withdraw</h5>
            <?php if (empty($riwayat_withdraw)): ?>
                <div class="alert alert-info text-center">Belum ada riwayat withdraw.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered text-center align-middle">
                        <thead class="table-success">
                            <tr>
                                <th>No</th>
                                <th>Poin</th>
                                <th>Jumlah (Rp)</th>
                                <th>Bank</th>
                                <th>Nomor Rekening</th>
                                <th>Atas Nama</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($riwayat_withdraw as $i => $w): ?>
                                <?php
                                $status_lower = strtolower($w->status);
                                $badge_class = 'danger'; // default merah
                                if ($status_lower === 'success') {
                                    $badge_class = 'success';
                                } elseif ($status_lower === 'pending') {
                                    $badge_class = 'warning';
                                }
                                ?>
                                <tr>
                                    <td><?= $i + 1; ?></td>
                                    <td><?= number_format($w->poin); ?></td>
                                    <td>Rp <?= number_format($w->rupiah, 0, ',', '.'); ?></td>
                                    <td><?= htmlspecialchars($w->bank); ?></td>
                                    <td><?= htmlspecialchars($w->no_rekening); ?></td>
                                    <td><?= htmlspecialchars($w->nama_rekening); ?></td>
                                    <td><?= date('d-m-Y H:i', strtotime($w->created_at)); ?></td>
                                    <td>
                                        <span class="badge bg-<?= $badge_class; ?>">
                                            <?= ucwords($status_lower); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
            <?php endif ?>
        </div>
    </div>

</div>