<style>
    .btn-xs-custom {
        padding: 0.35rem 0.6rem;
        font-size: 0.85rem;
        border-radius: 0.3rem;
    }

    .btn-xs-custom .small-icon {
        font-size: 1rem;
        margin-top: 1px;
    }
</style>

<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">Saldo Pengguna</h1>
        <p class="lead">Data poin dan saldo setiap pengguna</p>
    </div>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success text-center"><?= $this->session->flashdata('success'); ?></div>
    <?php elseif ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger text-center"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <div class="table-responsive bg-white p-3 rounded shadow-sm">
        <table class="table table-bordered table-hover text-center align-middle">
            <thead class="table-success">
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Nama Lengkap</th>
                    <th>Poin</th>
                    <th>Estimasi Saldo (Rp)</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($saldo_pengguna)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada data saldo pengguna</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($saldo_pengguna as $i => $user): ?>
                        <tr>
                            <td><?= $i + 1; ?></td>
                            <td><?= htmlspecialchars($user->username); ?></td>
                            <td><?= htmlspecialchars($user->nama_lengkap); ?></td>
                            <td><?= number_format((float) $user->poin); ?></td>
                            <td>Rp <?= number_format((float) $user->poin * 100, 0, ',', '.'); ?></td>
                            <td>
                                <a href="<?= site_url('admin/detail_saldo/' . $user->user_id); ?>"
                                    class="btn btn-xs-custom btn-sm d-inline-flex align-items-center gap-1 btn-outline-primary shadow-sm">
                                    <i class="bi bi-eye small-icon"></i> Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>