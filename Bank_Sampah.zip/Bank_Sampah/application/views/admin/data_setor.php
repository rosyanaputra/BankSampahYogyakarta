<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">Data Setoran Sampah</h1>
        <p class="lead">Lihat dan kelola data setoran dari pengguna</p>
    </div>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success text-center"><?= $this->session->flashdata('success'); ?></div>
    <?php elseif ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger text-center"><?= $this->session->flashdata('error'); ?></div>
    <?php endif; ?>

    <div class="table-responsive bg-white p-3 rounded shadow-sm">
        <table class="table table-bordered table-hover text-center align-middle">
            <thead class="table-success">
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Jenis Sampah</th>
                    <th>Berat (kg)</th>
                    <th>Alamat</th>
                    <th>Catatan</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($setoran)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data setoran</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($setoran as $i => $row): ?>
                        <tr>
                            <td><?= $i + 1; ?></td>
                            <td><?= htmlspecialchars($row->username); ?></td>
                            <td><?= htmlspecialchars($row->jenis_sampah); ?></td>
                            <td><?= number_format($row->berat, 2); ?></td>
                            <td><?= htmlspecialchars($row->alamat); ?></td>
                            <td><?= htmlspecialchars($row->catatan); ?></td>
                            <td><?= date('d-m-Y H:i', strtotime($row->created_at)); ?></td>
                            <td>
                                <select class="form-select form-select-sm status-dropdown fw-bold text-white text-center" data-id="<?= $row->id; ?>" style="background-color:
                                    <?= $row->status == 'selesai' ? '#28a745' : ($row->status == 'sedang diproses' ? '#ffc107' : '#6c757d') ?>;">
                                    <option value="menunggu" <?= $row->status == 'menunggu' ? 'selected' : '' ?>>Menunggu</option>
                                    <option value="sedang diproses" <?= $row->status == 'sedang diproses' ? 'selected' : '' ?>>Sedang Diproses</option>
                                    <option value="selesai" <?= $row->status == 'selesai' ? 'selected' : '' ?>>Selesai</option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    document.querySelectorAll('.status-dropdown').forEach(function(select) {
        select.addEventListener('change', function() {
            const id = this.dataset.id;
            const status = this.value;

            fetch("<?= site_url('admin/update_status_setoran'); ?>", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `id=${id}&status=${status}`
                }).then(res => res.text())
                .then(response => {
                    // Update warna background sesuai status
                    const warna = {
                        'menunggu': '#6c757d',
                        'sedang diproses': '#ffc107',
                        'selesai': '#28a745'
                    };
                    this.style.backgroundColor = warna[status];
                }).catch(err => {
                    alert('Gagal memperbarui status.');
                });
        });
    });
</script>