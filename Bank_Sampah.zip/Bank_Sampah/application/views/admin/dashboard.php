<div class="main-content">
    <div class="hero text-center mb-5">
        <h1 class="fw-bold">Dashboard Admin</h1>
        <p class="lead">Selamat datang di Panel Admin Bank Sampah Digital Yogyakarta</p>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow text-center p-4">
                <i class="bi bi-people display-4 text-success mb-3"></i>
                <h5 class="fw-bold">Manajemen Pengguna</h5>
                <p class="text-muted">Kelola data akun pengguna</p>
                <a href="<?= site_url('admin/manajemen_pengguna'); ?>" class="btn btn-outline-success mt-3">Lihat Data</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow text-center p-4">
                <i class="bi bi-cash-stack display-4 text-success mb-3"></i>
                <h5 class="fw-bold">Withdraw</h5>
                <p class="text-muted">Verifikasi permintaan pencairan poin</p>
                <a href="<?= site_url('admin/withdraw'); ?>" class="btn btn-outline-success mt-3">Kelola Withdraw</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow text-center p-4">
                <i class="bi bi-recycle display-4 text-success mb-3"></i>
                <h5 class="fw-bold">Data Setor</h5>
                <p class="text-muted">Pantau semua aktivitas penyetoran sampah</p>
                <a href="<?= site_url('admin/data_setor'); ?>" class="btn btn-outline-success mt-3">Lihat Aktivitas</a>
            </div>
        </div>
    </div>
</div>