-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2025 at 06:01 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank_sampah`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `phone`, `message`, `created_at`) VALUES
(1, 'my full name', 'me@mydomain.com', '(123) 456-7890', '30', '2025-07-20 05:09:14'),
(2, 'my full name', 'me@mydomain.com', '(123) 456-7890', '30', '2025-07-20 05:53:08');

-- --------------------------------------------------------

--
-- Table structure for table `saldo`
--

CREATE TABLE `saldo` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `poin` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saldo`
--

INSERT INTO `saldo` (`id`, `user_id`, `poin`, `updated_at`) VALUES
(1, 2, 2700, '2025-08-01 08:37:04');

-- --------------------------------------------------------

--
-- Table structure for table `setoran_sampah`
--

CREATE TABLE `setoran_sampah` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `jenis_sampah` varchar(50) DEFAULT NULL,
  `berat` decimal(6,2) NOT NULL,
  `catatan` text DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `poin` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'menunggu'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `setoran_sampah`
--

INSERT INTO `setoran_sampah` (`id`, `user_id`, `jenis_sampah`, `berat`, `catatan`, `alamat`, `latitude`, `longitude`, `created_at`, `poin`, `status`) VALUES
(17, 2, 'anorganik', '50.00', 'logam', 'Tegalrejo, Yogyakarta, Special Region of Yogyakarta, Java, 55244, Indonesia', '-7.791262', '110.350155', '2025-07-23 08:34:33', 300, 'menunggu'),
(18, 2, 'anorganik', '600.00', 'besi', 'Forriz, Jalan Haji Oemar Said Cokroaminoto, Pakuncen, Wirobrajan, Yogyakarta, Special Region of Yogyakarta, Java, 55253, Indonesia', '-7.795431', '110.353353', '2025-07-23 08:45:37', 3600, 'sedang diproses');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `foto` varchar(255) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `nama_lengkap`, `email`, `no_hp`, `password`, `alamat`, `created_at`, `foto`, `role`) VALUES
(2, 'user1', 'asep', 'user1@gmail.com', '325626542643263634', '$2y$10$bvi8MA0MfPLfN8pYmGMa5.ffxJpPqUPmyjVhM7R3AgVX9aY4v8NXm', 'yogyakarta', '2025-07-22 08:12:53', 'profile_2.jpeg', 'user'),
(7, 'admin1', 'ADMIN BANK SAMPAH YOGYAKARTA', 'admin1@gmail.com', '987346677522', '$2y$10$oiB/ESenCYOXxMEzM55mqe3Matk1feZetuhwdZNDmgxqFCKkFoUoW', 'sleman, Yogyakarta', '2025-08-01 04:15:06', 'default.jpeg', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw`
--

CREATE TABLE `withdraw` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `poin` int(11) NOT NULL,
  `rupiah` int(11) NOT NULL,
  `bank` varchar(50) DEFAULT NULL,
  `no_rekening` varchar(50) DEFAULT NULL,
  `nama_rekening` varchar(100) DEFAULT NULL,
  `status` enum('pending','success','failed') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `withdraw`
--

INSERT INTO `withdraw` (`id`, `user_id`, `poin`, `rupiah`, `bank`, `no_rekening`, `nama_rekening`, `status`, `created_at`) VALUES
(1, 2, 300, 30000, 'BCA', '0169518735', 'Alex', 'pending', '2025-07-23 08:44:39'),
(2, 2, 300, 30000, 'BCA', '0169518735', 'Alex', 'pending', '2025-07-23 08:48:27'),
(3, 2, 300, 30000, 'BCA', '0169518735', 'Alex', 'pending', '2025-07-23 09:18:27'),
(4, 2, 300, 30000, 'BCA', '0169518735', 'Alex', 'success', '2025-08-01 03:37:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saldo`
--
ALTER TABLE `saldo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `setoran_sampah`
--
ALTER TABLE `setoran_sampah`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_setoran` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw`
--
ALTER TABLE `withdraw`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `saldo`
--
ALTER TABLE `saldo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setoran_sampah`
--
ALTER TABLE `setoran_sampah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `withdraw`
--
ALTER TABLE `withdraw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `saldo`
--
ALTER TABLE `saldo`
  ADD CONSTRAINT `saldo_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `setoran_sampah`
--
ALTER TABLE `setoran_sampah`
  ADD CONSTRAINT `fk_user_setoran` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
